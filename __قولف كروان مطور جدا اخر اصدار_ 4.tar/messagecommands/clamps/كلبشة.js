const userBase = require('../../Models/userBase')
    , guildBase = require('../../Models/guildBase')
    , { clambRole, clambLog } = require('../../config.json')

module.exports = {
    name: `كلبشة`,
    run: async (client, message, args, Discord) => {
        if (!message.member.roles.cache.has(clambRole)) return;

        let user = message.mentions.users.first()
        if (!user) return message.reply({
            content: `:x: | يجب عليك ذكر الشخص الذي تريد كلبشته`
        })

        if(user.bot) return message.reply({
            content: `:x: | لا يمكنك كلبشة البوتات`
        })

        let db = await guildBase.findOne({ guild: message.guild.id })
        if (!db) {
            db = new guildBase({ guild: message.guild.id })
            await db.save();
        }

        let check = db.joins.find(c => c.user === message.author.id)
        if (!check) return message.reply({
            content: `:x: | يجب تسجيل دخولك حتى تتمكن من استخدام الامر`
        })

        let check2 = db.joins.find(c => c.user === user.id)
        if (!check2) return message.reply({
            content: `:x: | لن تتمكن من كلبشة ${user} لانه غير مسجل دخوله`
        })

        let userData = await userBase.findOne({ guild: message.guild.id, user: user.id })
        if (!userData) {
            userData = new userBase({ guild: message.guild.id, user: user.id })
            await userData.save();
        }

        userData = userData[check2.character]

        if(userData.clamped) return message.reply({
            content: `:x: | تم كلبشة ${user} في الشخصية ${check2.character === "c1" ? "الاولى" : "الثانية"} من قبل`
        })

        let mainData = await userBase.findOne({ guild: message.guild.id, user: message.author.id })
        if (!mainData) {
            mainData = new userBase({ guild: message.guild.id, user: message.author.id })
            await mainData.save();
        }

        mainData = mainData[check.character]

        let index = mainData.inv.findIndex(c => c.name.toLowerCase() === "handcuffs")
        if (index == -1) return message.reply({
            content: `:x: | لا يمكنك كلبشة ${user} لانك لا تملك كلبشات داخل حقيبة الشخصية ${check.character === "c1" ? "الاولى" : "الثانية"}`
        })

        mainData.inv[index].count === 1 ? mainData.inv.splice(index, 1) : mainData.inv[index].count -= 1

        await userBase.updateOne({ guild: message.guild.id, user: message.author.id },
            {
                $set: {
                    [`${check.character}.inv`]: mainData.inv
                }
            }
        );

        await userBase.updateOne({ guild: message.guild.id, user: user.id },
            {
                $set: {
                    [`${check2.character}.clamped`]: true
                }
            }
        );

        user.send({
            embeds: [new Discord.EmbedBuilder().setColor("#00dfff").setDescription(`**<:1OL_1warrn:1252516293379231764> - تم كلبشتك من قبل | ${message.author}

<:tl:1262585314787201034> - الشخصية | ${check2.character === "c1" ? "1" : "2"}

\`\` TOWN LAW System . \`\`**`)]
        })

        await message.reply({
            content: `:white_check_mark: | تم كلبشة ${user} بنجاح`
        })

        let log = message.guild.channels.cache.get(clambLog)
        if(!log) return;

        log.send({
            embeds: [new Discord.EmbedBuilder().setColor("#00dfff").setDescription(`** <:1OL_1ruless:1252516289457553456> - تم كلبشة | ${user}

<:group2:1328358692676046879> - من قبل | ${message.author}

<:tl:1262585314787201034> - الشخصية | ${check2.character === "c1" ? "1" : "2"}

\`\` TOWN LAW System . \`\` **`)]
        })
    }
};