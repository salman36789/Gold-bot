const Discord = require("discord.js")
const { prices } = require("../../config.json")

module.exports = {
    name: `send-message6`,
    run: async (client, message, args) => {
        if (!message.member.permissions.has("8")) return;

        let embed = new Discord.EmbedBuilder()
            .setColor("#00dfff")
            .setImage("https://i.postimg.cc/4xSjBrQM/image.png")
            .setDescription(`** Manufacturing, assembly and development system : In order to collect, you must click on the option at the bottom and click on assembly, and you must follow the mentioned Rules <#1329152030840983734> **`);

        let row = new Discord.ActionRowBuilder().addComponents(
            new Discord.StringSelectMenuBuilder()
                .setCustomId("mach_menu")
                .setMaxValues(1)
                .setPlaceholder("Choose a product")
                .addOptions([
                    { label: "Manufacturing", value: "manufacturing", emoji: "<:1OL_manege:1275534310421565522> ", description: `لبدء التصنيع` },
                    { label: "Collecting", value: "collecting", emoji: "<:1OL_1repost:1329262249415676025> ", description: `لبدء التجميع` },
                    { label: "Upgrade", value: "upgrade", emoji: "<:gulfbot_1134085476714823701:1268200952905601036>", description: `لبدء التطوير` },
                ])
        )

        message.delete();
        await message.channel.send({
            embeds: [embed],
            components: [row]
        })

    }
};