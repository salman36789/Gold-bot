const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  SelectMenuBuilder,
  EmbedBuilder,
} = require("discord.js");
const userBase = require('../../Models/userBase');
const guildBase = require('../../Models/guildBase');

// دالة لعرض الأرباح بشكل عشوائي
const getRandomEarnings = () => {
  const earnings = [600, 700, 800, 900, 1000];
  return earnings[Math.floor(Math.random() * earnings.length)];
};

// دالة لإرسال المراحل المشتركة بين الوظائف
const sendStepEmbed = async (interaction, title, description, buttonLabel, nextStepId, embedColor = "#00dfff") => {
  const embed = new EmbedBuilder()
    .setTitle(title)
    .setDescription(description)
    .setColor(embedColor);
  
  const button = new ButtonBuilder()
    .setCustomId(nextStepId)
    .setLabel(buttonLabel)
    .setStyle(ButtonStyle.Primary);
  
  const buttonRow = new ActionRowBuilder().addComponents(button);
  
  await interaction.update({
    embeds: [embed],
    components: [buttonRow],
  });
};

// Main command handler
module.exports = {
  name: "send-message17",
  run: async (client, message, args) => {
    const embed = new EmbedBuilder()
      .setTitle("JOBS")
      .setDescription(`
        🚨 **قبل بدء المهام، يرجى قراءة القواعد هنا: [Jobs-Rules](#).**  
        🏢 **اختر من القائمة أدناه للاستمرار.**
      `)
      .setImage("https://images-ext-1.discordapp.net/external/pU73k0ng2OYaAlMZbenpnFbdoB1Y2LeXhVskiOMSk6w/https/i.postimg.cc/jSsYsncH/Whats-App-Image-2025-01-14-at-7-41-43-PM.jpg")
      .setColor("#00dfff")
      .setFooter({ text: "System" });

    const menu = new SelectMenuBuilder()
      .setCustomId("job-selection")
      .setPlaceholder("اختر الوظيفة")
      .addOptions([
        {
          label: "وظيفة تاكسي",
          description: "نقل الركاب إلى وجهاتهم.",
          value: "taxi_job",
          emoji: "🚖",
        },
        {
          label: "توصيل بيتزا",
          description: "توصيل البيتزا للعملاء.",
          value: "pizza_delivery",
          emoji: "🍕",
        },
      ]);

    const actionRow = new ActionRowBuilder().addComponents(menu);
    await message.channel.send({ embeds: [embed], components: [actionRow] });

    client.on("interactionCreate", async (interaction) => {
      if (interaction.isSelectMenu() && interaction.customId === "job-selection") {
        const selected = interaction.values[0];

        if (selected === "taxi_job") {
          await sendStepEmbed(
            interaction,
            "✔️ - وظيفة تاكسي",
            `
              ✅ **تحديد موقع العميل**
              📍 **# الخطوة الأولى**
              - تم تحديد موقع العميل، قم بالذهاب إلى الموقع.
              - عند الوصول، اضغط على زر **التالي** للانتقال إلى الخطوة التالية.
            `,
            "التالي",
            "taxi_step2"
          );
        } else if (selected === "pizza_delivery") {
          await sendStepEmbed(
            interaction,
            "✔️ - توصيل بيتزا",
            `
              ✅ **جاري تركيب الطلب**
              🍕 **# الخطوة الأولى**
              - جاري تركيب الطلب.
              - عند الانتهاء، اضغط على زر **تأكيد** للانتقال إلى الخطوة التالية.
            `,
            "تأكيد",
            "pizza_step2"
          );
        }
      }

      // الخطوات التالية مع الأزرار
      if (interaction.isButton()) {
        if (interaction.customId === "pizza_step2") {
          await sendStepEmbed(
            interaction,
            "✔️ - توصيل بيتزا",
            `
              ✅ **ذهاب إلى الموقع المحدد**
              🛵 **# الخطوة الثانية**
              - قم بالتوجه إلى الموقع لتوصيل البيتزا.
              - عند الوصول، اضغط على زر **توصيل** للانتقال إلى الخطوة التالية.
            `,
            "توصيل",
            "pizza_step3"
          );
        } else if (interaction.customId === "pizza_step3") {
          await sendStepEmbed(
            interaction,
            "✔️ - توصيل بيتزا",
            `
              ✅ **إنزال البيتزا**
              🍕 **# الخطوة الثالثة**
              - قم بتسليم البيتزا للعميل.
              - اضغط على زر **إنهاء** لإنهاء المهمة.
            `,
            "إنهاء",
            "pizza_complete"
          );
        } else if (interaction.customId === "pizza_complete") {
          const earnings = getRandomEarnings();
          await sendFinalStep(interaction, "توصيل بيتزا", earnings);
        }

        // مثال آخر للتاكسي
        if (interaction.customId === "taxi_step2") {
          await sendStepEmbed(
            interaction,
            "✔️ - وظيفة تاكسي",
            `
              ✅ **قم بتوصيل العميل**
              🚖 **# الخطوة الثانية**
              - اركب العميل وابدأ الرحلة.
              - عند الوصول، اضغط على زر **إتمام** لإنهاء المهمة.
            `,
            "إتمام",
            "taxi_complete"
          );
        } else if (interaction.customId === "taxi_complete") {
          const earnings = getRandomEarnings();
          await sendFinalStep(interaction, "وظيفة تاكسي", earnings);
        }
      }
    });
  },
};

// دالة لعرض الأرباح النهائية
const sendFinalStep = async (interaction, jobTitle, earnings) => {
  const embed = new EmbedBuilder()
    .setTitle(`✔️ - ${jobTitle}`)
    .setDescription(`
      ✅ **الأرباح**
      - المهمة تم إنجازها بنجاح. 💰
      - **المبلغ الذي ربحته: (${earnings} $)**.
      🔄 **للاستمرار اضغط على (مرة أخرى).**
      ❌ **لإنهاء المهمة اضغط على (إيقاف).**
    `)
    .setColor("#00dfff");

  const againButton = new ButtonBuilder()
    .setCustomId("again-task")
    .setLabel("مرة أخرى")
    .setStyle(ButtonStyle.Success);

  const stopButton = new ButtonBuilder()
    .setCustomId("stop-task")
    .setLabel("إيقاف")
    .setStyle(ButtonStyle.Danger);

  const buttonRow = new ActionRowBuilder().addComponents(againButton, stopButton);
  await interaction.update({
    embeds: [embed],
    components: [buttonRow],
  });
};