const Discord = require("discord.js")

module.exports = {
  name: `send-message10`,
  run: async (client, message, args) => {
    if (!message.member.permissions.has("8")) return;

    let embed = new Discord.EmbedBuilder()
      .setColor("#00dfff")
      .setImage("https://i.postimg.cc/hPcv9Pg2/image.png")
      .setDescription(`**Choose Resuscitation**`);

    let row = new Discord.ActionRowBuilder().addComponents(
        new Discord.ButtonBuilder()
        .setCustomId("en3ash_main")
        .setLabel("إنعاش")
        .setDisabled(true)
        .setStyle("Secondary"),
        
        new Discord.ButtonBuilder()
        .setCustomId("en3ash_hospital")
        .setLabel("إنعاش مستشفى")
        .setStyle("Secondary"),

        new Discord.ButtonBuilder()
        .setCustomId("en3ash_magic")
        .setLabel("إنعاش ساحرة")
        .setStyle("Secondary")
    )

    message.delete();
    await message.channel.send({
      embeds: [embed],
      components: [row]
    })

  }
};