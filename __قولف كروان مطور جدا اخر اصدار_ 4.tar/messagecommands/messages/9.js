const Discord = require("discord.js")
const { prices } = require("../../config.json")

module.exports = {
  name: `send-message9`,
  run: async (client, message, args) => {
    if (!message.member.permissions.has("8")) return;

    let embed = new Discord.EmbedBuilder()
      .setColor("#00dfff")
      .setAuthor({ name: "IKEA" })
      .setImage("https://i.imgur.com/GI1SDNp.png")
      .setDescription(`** 🛒 - Choose what you want from IKEA **`);

    let row = new Discord.ActionRowBuilder().addComponents(
      new Discord.StringSelectMenuBuilder()
        .setCustomId("buy_menu")
        .setMaxValues(2)
        .setPlaceholder("Choose a product")
        .addOptions([
          { label: "Phone", value: "phone", emoji: "<:Phone_MN:1277081453053874277>", description: `Price | ${prices["phone"]}$` },
          { label: "Divingkit", value: "divingkit", emoji: "<:gulfbot_1271792189957214291:1271955972146855947>", description: `Price | ${prices["divingkit"]}$` },
          { label: "Barshot", value: "barshot", emoji: "<:gulfbot_1138449559924781167:1271956381456666645>", description: `Price | ${prices["barshot"]}$` },
          { label: "Drill", value: "drill", emoji: "<:gulfbot_1271792639125225507:1271955973355077764>", description: `Price | ${prices["drill"]}$` },
          { label: "Radio", value: "radio", emoji: "<:gulfbot_1271769441624920087:1271955976093831210>", description: `Price | ${prices["radio"]}$` },
          { label: "Searchlight", value: "searchlight", emoji: "<:gulfbot_1271798397992435755:1271956382773411883>", description: `Price | ${prices["searchlight"]}$` }
        ])
    )

    message.delete();
    await message.channel.send({
      embeds: [embed],
      components: [row]
    })

  }
};