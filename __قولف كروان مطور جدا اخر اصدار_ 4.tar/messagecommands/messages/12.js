const Discord = require("discord.js")
const { builds } = require("../../builds.json")
module.exports = {
    name: `send-message12`,
    run: async (client, message, args) => {
        if (!message.member.permissions.has("8")) return;

        let embed = new Discord.EmbedBuilder()
            .setColor("#00dfff")
            .setImage("https://i.imgur.com/ixKPd39.png")
            .setTitle("<:LOOCC1:1288390496905072673> - TOWN LAW Real Estate .")
            .setDescription(`**__Apartment You have to press the bottom button :arrow_down: and you have to choose the house__**`);

        let row = new Discord.ActionRowBuilder().addComponents(
            new Discord.StringSelectMenuBuilder()
                .setCustomId("builds_menu")
                .setMaxValues(1)
                .setPlaceholder("Select the property")
                .addOptions(builds.map((data, i) => { return { emoji: "🏠", label: `${data.name}`, description: `Price | ${data.price.toLocaleString("en-US")}`, value: `${i}` } }))
        )

        message.delete();
        await message.channel.send({
            embeds: [embed],
            components: [row]
        })

    }
};