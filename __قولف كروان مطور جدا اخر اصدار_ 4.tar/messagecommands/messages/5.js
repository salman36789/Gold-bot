const Discord = require("discord.js")
const { prices } = require("../../config.json")

module.exports = {
  name: `send-message5`,
  run: async (client, message, args) => {
    if (!message.member.permissions.has("8")) return;

    let embed = new Discord.EmbedBuilder()
      .setColor("#00dfff")
      .setAuthor({ name: "TLRP Store" })
      .setImage("https://i.imgur.com/ZUe7Col.png")
      .setDescription(`** Town Law - Crime Store ☠️**`);

    let row = new Discord.ActionRowBuilder().addComponents(
      new Discord.StringSelectMenuBuilder()
        .setCustomId("buy_menu")
        .setMaxValues(2)
        .setPlaceholder("Choose a product")
        .addOptions([
          { label: "Locksmith", value: "locksmith", emoji: "<:gulfbot_1271769662773792799:1271956616824094812>", description: `Price | ${prices["locksmith"]}$` },
          { label: "Hacking Flash", value: "hacking_flash", emoji: "<:gulfbot_1271792993371947143:1271955974298533972>", description: `Price | ${prices["hacking_flash"]}$` },
          { label: "Hacking Laptop", value: "hacking_laptop", emoji: "<:gulfbot_1263057305046351944:1272212214354542644>", description: `Price | ${prices["hacking_laptop"]}$` },
          { label: "Electric Laptop", value: "electric_laptop", emoji: "<:gulfbot_1271771205183209553:1272212213075284000>", description: `Price | ${prices["electric_laptop"]}$` },
          { label: "Locksmith M2", value: "locksmith_m2", emoji: "<:gulfbot_1246177667972206634:1272212679657787485>", description: `Price | ${prices["locksmith_m2"]}$` },
          { label: "Frequency Waves", value: "frequency_waves", emoji: "<:gulfbot_1271802934656634960:1272219077322215546>", description: `Price | ${prices["frequency_waves"]}$` },
          { label: "Screwdriver", value: "screwdriver", emoji: "<:gulfbot_1264080639364300865:1272218781372121161>", description: `Price | ${prices["screwdriver"]}$` },
          { label: "Large Bag", value: "large_bag", emoji: "<:gulfbot_1263057363250839564:1272219674318340178>", description: `Price | ${prices["large_bag"]}$` },
          { label: "Heavy Armor", value: "heavy_armor", emoji: "<:gulfbot_1271769539566239776:1272219672804069397>", description: `Price | ${prices["heavy_armor"]}$` },
          { label: "Knife", value: "knife", emoji: "<:gulfbot_1271771088040362015:1272219675824095243>", description: `Price | ${prices["knife"]}$` },
          { label: "Handcuffs", value: "handcuffs", emoji: "<:gulfbot_1223655113529495684:1272220462545506334>", description: `Price | ${prices["handcuffs"]}$` }
        ])
    )

    message.delete();
    await message.channel.send({
      embeds: [embed],
      components: [row]
    })

  }
};