const Discord = require("discord.js")
const { cars } = require("../../cars.json")
module.exports = {
    name: `send-message13`,
    run: async (client, message, args) => {
        if (!message.member.permissions.has("8")) return;

        let embed = new Discord.EmbedBuilder()
            .setColor("#00dfff")
            .setImage("https://i.imgur.com/rHrn866.png")
            .setTitle("<:tl:1262585306402521159> — TOWN LAW Exhibition")
            .setDescription(`**Premium Deluxe Motorsport showroom for luxury and sports cars is the oldest showroom in TOWN LAW 

Join us at the Premium Deluxe Motorsport exhibition to experience the latest luxury and sports cars. Discover our type of distinctive luxury vehicles and enjoy exclusive offers.**`);

        let row = new Discord.ActionRowBuilder().addComponents(
            new Discord.StringSelectMenuBuilder()
                .setCustomId("cars_menu")
                .setMaxValues(1)
                .setPlaceholder("Select the property")
                .addOptions(cars.map((data, i) => { return { emoji: "🚗", label: `${data.name}`, description: `Price | ${data.price.toLocaleString("en-US")}`, value: `${i}` } }))
        )
        
        message.delete();
        await message.channel.send({
            embeds: [embed],
            components: [row]
        })

    }
};