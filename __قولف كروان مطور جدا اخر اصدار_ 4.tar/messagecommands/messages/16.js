const Discord = require("discord.js")
module.exports = {
    name: `send-message16`,
    run: async (client, message, args) => {
        if (!message.member.permissions.has("8")) return;

         let embed = new Discord.EmbedBuilder()
            .setColor("#00dfff")
            .setImage("https://media.discordapp.net/attachments/1336437701527732324/1337776428376395836/KBdbtedwIx.jpg?ex=67a8ace3&is=67a75b63&hm=39c0a20bfec6a2035e18f137da6ba367f6f9599c2d585f750c523a29dcfa680b&")
            .setDescription(`**<:emoji_94:1254338768429649991> - To receive military equipment, click Next . 

\`\` Police System \`\`**`);

        let row = new Discord.ActionRowBuilder().addComponents(
            new Discord.StringSelectMenuBuilder()
            .setCustomId("panic_menu")
            .addOptions([
                { label: "10-13 Shots Fired .", value: "shot", emoji: "<:tl:1262585312136396963>" },
                { label: "1-10 Vehicle chase operation .", value: "vehicle", emoji: "<:tl:1262585312136396963>" },
                { label: "5-10 Vehicle theft .", value: "vehicleTheft", emoji: "<:tl:1262585312136396963>" },
                { label: "7-10 Robbery Store .", value: "robberyStore", emoji: "<:tl:1262585312136396963>" },
                { label: "Panic .", value: "ppanic", emoji: "<:tl:1262585312136396963>" },
                { label: "Code 0", value: "code_0", emoji: "<:tl:1262585312136396963>" }
            ])
            .setMaxValues(1)
        )
        
        message.delete();
        await message.channel.send({
            embeds: [embed],
            content: `||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​|| _ _ _ _ _ _ @everyone`,
            components: [row]
        })

    }
};