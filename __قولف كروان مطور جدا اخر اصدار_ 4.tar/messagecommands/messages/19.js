const Discord = require("discord.js");
const client = new Discord.Client({
    intents: [
        Discord.GatewayIntentBits.MessageContent,
        Discord.GatewayIntentBits.Guilds,
        Discord.GatewayIntentBits.GuildMembers,
        Discord.GatewayIntentBits.GuildMessages,
        Discord.GatewayIntentBits.DirectMessages
    ],
    partials: [
        Discord.Partials.GuildScheduledEvent,
        Discord.Partials.Reaction,
        Discord.Partials.Message,
        Discord.Partials.User,
        Discord.Partials.Channel,
        Discord.Partials.GuildMember
    ]
});

const { 
    Client, 
    GatewayIntentBits, 
    EmbedBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    ModalBuilder, 
    TextInputBuilder, 
    TextInputStyle, 
    ComponentType 
} = require('discord.js');
const userBase = require('../../Models/userBase');
const guildBase = require('../../Models/guildBase');
const { invLog } = require('../../config.json');

module.exports = {
    name: 'send-message19',
    run: async (client, message) => {
        if (!message.member.roles.cache.has('1329391491369664553')) {
            return message.reply({ content: ':x: | ليس لديك الدور المطلوب لاستخدام هذا الأمر.', ephemeral: true });
        }

        let embed = new Discord.EmbedBuilder()
            .setColor('#00dfff')
            .setTitle('**<:group2:1328358692676046879> \`\` Player Control Panel \`\`**')
            .setDescription(`**
From here You Can Control Your Player <:Online:1250965894205669406> 
-# من هنا يمكنك التحكم في لاعبك

 <:emoji_286:1333040124908273686> | Inventory 
-# كشف الحقيبة 

<:1OL_1repost:1288375897531093025>  | Give item
-# لأعطاء الشخص غرض من حقيبتك

<:1OL_job3:1288390482921263145>  | Use Item 
-# لأستخدام غرض من حقيبتك ( رمي الغرض )
**`)
        .setImage("https://media.discordapp.net/attachments/1336437701527732324/1337776428376395836/KBdbtedwIx.jpg?ex=67c1b963&is=67c067e3&hm=09916d70795ab3303f8fd3b1ff2cec0ec27e75e847b5c6510bac48281c6358a9&")
            .setTimestamp();

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('inventory')
                .setLabel('Inventory')
                .setEmoji('<:emoji_286:1333040124908273686>')              .setStyle(ButtonStyle.Primary),
            
            new ButtonBuilder()
                .setCustomId('give_item')
                .setLabel('Give Item')
                .setEmoji('<:1OL_1repost:1329262249415676025>')
           .setStyle(ButtonStyle.Primary),
            
            new ButtonBuilder()
                .setCustomId('use_item')
                .setLabel('Use Item')
                .setEmoji('<:1OL_job3:1288390482921263145>')            .setStyle(ButtonStyle.Primary),
            
            
        );

         const msg = await 
         message.delete();
         message.channel.send({ embeds: [embed],  content: `||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​|| _ _ _ _ _ _ @everyone`,components: [row] });

        client.on('interactionCreate', async (interaction) => {
            if (!interaction.isButton()) return;

          

            switch (interaction.customId) {
                case 'inventory': {
                      const db = await guildBase.findOne({ guild: interaction.guild.id });
            if (!db) return interaction.reply({ content: ':x: | لم يتم العثور على بيانات لهذا الخادم.', ephemeral: true });

            const userData = await userBase.findOne({ guild: interaction.guild.id, user: interaction.user.id });
            if (!userData) return interaction.reply({ content: ':x: | لم يتم العثور على بيانات للمستخدم الخاص بك.', ephemeral: true });

            const character = db.joins.find(c => c.user === interaction.user.id)?.character;
            if (!character) return interaction.reply({ content: ':x: | يجب تسجيل الدخول أولاً.', ephemeral: true });
                     const inventory = userData[character]?.inv || [];
                    
                    if (!inventory.length) {
                        return interaction.reply({ content: ':x: | الحقيبة الخاصه بك فارغ.', ephemeral: true });
                    }

                    const inventoryEmbed = new EmbedBuilder()
                        .setColor('#00dfff')
                        .setTitle('Inventory')
.setDescription(inventory.map((item, i) => `** 
${i + 1}. ${item.name} - Amount : ${item.count}**`).join('\n'))
                        .setTimestamp();

                    return interaction.reply({ embeds: [inventoryEmbed], ephemeral: true });
                }

                case 'use_item': {
                      const db = await guildBase.findOne({ guild: interaction.guild.id });
            if (!db) return interaction.reply({ content: ':x: | لم يتم العثور على بيانات لهذا الخادم.', ephemeral: true });

            const userData = await userBase.findOne({ guild: interaction.guild.id, user: interaction.user.id });
            if (!userData) return interaction.reply({ content: ':x: | لم يتم العثور على بيانات للمستخدم الخاص بك.', ephemeral: true });

            const character = db.joins.find(c => c.user === interaction.user.id)?.character;
            if (!character) return interaction.reply({ content: ':x: | يجب تسجيل الدخول أولاً.', ephemeral: true });
                     const inventory = userData[character]?.inv || [];
                    
                    const modal = new ModalBuilder()
                        .setCustomId('use_item_modal')
                        .setTitle('استخدام عنصر');

                    modal.addComponents(
                        new ActionRowBuilder().addComponents(
                            new TextInputBuilder()
                                .setCustomId('item_name')
                                .setLabel('اسم العنصر')
                                .setStyle(TextInputStyle.Short)
                                .setRequired(true)
                        ),
                        new ActionRowBuilder().addComponents(
                            new TextInputBuilder()
                                .setCustomId('quantity')
                                .setLabel('الكمية')
                                .setStyle(TextInputStyle.Short)
                                .setRequired(true)
                        )
                    );

                    await interaction.showModal(modal);
                    break;
                }

                case 'give_item': {
                      const db = await guildBase.findOne({ guild: interaction.guild.id });
            if (!db) return interaction.reply({ content: ':x: | لم يتم العثور على بيانات لهذا الخادم.', ephemeral: true });

            const userData = await userBase.findOne({ guild: interaction.guild.id, user: interaction.user.id });
            if (!userData) return interaction.reply({ content: ':x: | لم يتم العثور على بيانات للمستخدم الخاص بك.', ephemeral: true });

            const character = db.joins.find(c => c.user === interaction.user.id)?.character;
            if (!character) return interaction.reply({ content: ':x: | يجب تسجيل الدخول أولاً.', ephemeral: true });
                     const inventory = userData[character]?.inv || [];
                    const modal = new ModalBuilder()
                        .setCustomId('give_item_modal')
                        .setTitle('إعطاء عنصر');

                    modal.addComponents(
                        new ActionRowBuilder().addComponents(
                            new TextInputBuilder()
                                .setCustomId('member_id')
                                .setLabel('معرف العضو')
                                .setStyle(TextInputStyle.Short)
                                .setRequired(true)
                        ),
                        new ActionRowBuilder().addComponents(
                            new TextInputBuilder()
                                .setCustomId('item_name')
                                .setLabel('اسم العنصر')
                                .setStyle(TextInputStyle.Short)
                                .setRequired(true)
                        ),
                        new ActionRowBuilder().addComponents(
                            new TextInputBuilder()
                                .setCustomId('quantity')
                                .setLabel('الكمية')
                                .setStyle(TextInputStyle.Short)
                                .setRequired(true)
                        )
                    );

                    await interaction.showModal(modal);
                    break;
                }
            }
        });

        client.on('interactionCreate', async (modalInteraction) => {
            if (!modalInteraction.isModalSubmit()) return;

            const modalId = modalInteraction.customId;
            const db = await guildBase.findOne({ guild: modalInteraction.guild.id });
            const userData = await userBase.findOne({ guild: modalInteraction.guild.id, user: modalInteraction.user.id });
            const character = db.joins.find(c => c.user === modalInteraction.user.id)?.character;

            if (modalId === 'use_item_modal') {
                const itemName = modalInteraction.fields.getTextInputValue('item_name');
                const quantity = parseInt(modalInteraction.fields.getTextInputValue('quantity'));

                const itemIndex = userData[character].inv.findIndex(item => item.name.toLowerCase() === itemName.toLowerCase());
                if (itemIndex === -1 || userData[character].inv[itemIndex].count < quantity) {
                    return modalInteraction.reply({ content: ':x: | العنصر غير موجود أو الكمية غير كافية.', ephemeral: true });
                }

                userData[character].inv[itemIndex].count -= quantity;
                if (userData[character].inv[itemIndex].count === 0) {
                    userData[character].inv.splice(itemIndex, 1);
                }

                await userBase.updateOne({ guild: modalInteraction.guild.id, user: modalInteraction.user.id }, { $set: { [`${character}.inv`]: userData[character].inv } });
                modalInteraction.reply({ content: `✅ | تم استخدام ${quantity} من ${itemName} بنجاح.`, ephemeral: true });

                const logChannel = modalInteraction.guild.channels.cache.get(invLog);
                if (logChannel) {
                    logChannel.send({ embeds: [new EmbedBuilder().setColor('#00dfff').setDescription(`**${modalInteraction.user.tag}** استخدم **${quantity} ${itemName}**.`)] });
                }
      } else if (modalId === 'give_item_modal') {
const memberId = modalInteraction.fields.getTextInputValue('member_id');
const itemName = modalInteraction.fields.getTextInputValue('item_name');
const quantity = parseInt(modalInteraction.fields.getTextInputValue('quantity'));

if (memberId === modalInteraction.user.id) {
return modalInteraction.reply({ content: ':x: | لم يتم العثور على المستلم.', ephemeral: true });
}

const recipientData = await userBase.findOne({ guild: modalInteraction.guild.id, user: memberId });
if (!recipientData) {
return modalInteraction.reply({ content: ':x: | العنصر غير موجود أو الكمية غير كافية.', ephemeral: true });
      }

                const recipientCharacter = db.joins.find(c => c.user === memberId)?.character;

                const itemIndex = userData[character].inv.findIndex(item => item.name.toLowerCase() === itemName.toLowerCase());
                if (itemIndex === -1 || userData[character].inv[itemIndex].count < quantity) {
                    return modalInteraction.reply({ content: ':x: | لا تستطيع اعطاء نفسك غرض.', ephemeral: true });
                }

                userData[character].inv[itemIndex].count -= quantity;
                if (userData[character].inv[itemIndex].count === 0) {
                    userData[character].inv.splice(itemIndex, 1);
                }

                const recipientItemIndex = recipientData[recipientCharacter].inv.findIndex(item => item.name.toLowerCase() === itemName.toLowerCase());
                if (recipientItemIndex === -1) {
                    recipientData[recipientCharacter].inv.push({ name: itemName, count: quantity });
                } else {
                    recipientData[recipientCharacter].inv[recipientItemIndex].count += quantity;
                }

                await userBase.updateOne({ guild: modalInteraction.guild.id, user: modalInteraction.user.id }, { $set: { [`${character}.inv`]: userData[character].inv } });
                await userBase.updateOne({ guild: modalInteraction.guild.id, user: memberId }, { $set: { [`${recipientCharacter}.inv`]: recipientData[recipientCharacter].inv } });

                modalInteraction.reply({ content: `✅ | تم إعطاء ${quantity} من ${itemName} إلى <@${memberId}> بنجاح.`, ephemeral: true });

                const logChannel = modalInteraction.guild.channels.cache.get(invLog);
                if (logChannel) {
                    logChannel.send({ embeds: [new EmbedBuilder().setColor('#00dfff').setDescription(`**${modalInteraction.user.tag}** أعطى **${quantity} ${itemName}** إلى **<@${memberId}>** .`)] });
                }
            }
        });
    }
};