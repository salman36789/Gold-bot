const Discord = require("discord.js")
module.exports = {
    name: `send-message14`,
    run: async (client, message, args) => {
        if (!message.member.permissions.has("8")) return;

        let embed = new Discord.EmbedBuilder()
            .setColor("#00dfff")
            .setImage("https://i.postimg.cc/jSsYsncH/Whats-App-Image-2025-01-14-at-7-41-43-PM.jpg")
            .setTitle(`** <:LSPD:1256478539579002920> - Storage ( 1 )

<:1OL_1warrn:1252516293379231764> - To receive military equipment, click Next .

Read The Rules

\`\` TOWN LAW Police \`\`**`);

        let row = new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder()
                .setCustomId("take_items")
                .setStyle("Success")
                .setLabel("Take")
        )
        
        message.delete();
        await message.channel.send({
            embeds: [embed],
            components: [row]
        })

    }
};