const Discord = require("discord.js")

module.exports = {
  name: `send-message11`,
  run: async (client, message, args) => {
    if (!message.member.permissions.has("8")) return;

    let embed = new Discord.EmbedBuilder()
      .setColor("#00dfff")
      .setImage("https://i.postimg.cc/rFgdH9bx/52-DE2968-8-A06-43-DC-A2-A2-D395-AF913-CFD.jpg")
      .setDescription(`**<:Phone_MN:1277081453053874277> - Phone .**`);

    let row = new Discord.ActionRowBuilder().addComponents(
        new Discord.ButtonBuilder()
        .setCustomId("phone_users")
        .setLabel("Apps")
        .setEmoji("<:Phone_MN:1284550446668714065>")
        .setStyle("Primary"),
        
        new Discord.ButtonBuilder()
        .setCustomId("phone_msg")
        .setLabel("Message")
        .setEmoji("<:1OL_1rulesx1:1288375900840263736>")
        .setStyle("Primary")
    )

    message.delete();
    await message.channel.send({
      embeds: [embed],
      components: [row]
    })

  }
};