const Discord = require("discord.js")

module.exports = {
  name: `send-message`,
  run: async (client, message, args) => {
    if (!message.member.permissions.has("8")) return;

    let embed = new Discord.EmbedBuilder()
      .setColor("#00dfff")
      .setAuthor({ name: "Character Selection" })
      .setImage("https://i.postimg.cc/KYdSvdKL/image.png")
      .setDescription(`**<a:ONLINE:1289715936886132831> - Choose Character\n<:tl:1262585314787201034> - Create Character**`);

    let row = new Discord.ActionRowBuilder().addComponents(
      new Discord.StringSelectMenuBuilder()
        .setCustomId("choose_character")
        .setMaxValues(1)
        .setPlaceholder("اختار الشخصية")
        .addOptions([
          { label: "First Character", value: "c1", emoji: "<:TLRP:1289346762472947814>", description: "لتقوم بأختيار كركترك الاول ." },
          { label: "Second Character", value: "c2", emoji: "<:TLRP:1289346762472947814>", description: "لتقوم بأختيار كركترك الثاني ." },
            { label: "Character Rules", value: "identity_rules", emoji: "<:TL:1252220974871609406>", description: "لعرض قوانين الشخصيات ." }
        ])
    );

    message.delete();
    await message.channel.send({
      embeds: [embed],
      components: [row]
    });
// استماع لاختيار المستخدم في Select Menu
    client.on("interactionCreate", async (interaction) => {
      if (!interaction.isStringSelectMenu()) return;
      if (interaction.customId !== "choose_character") return;

      if (interaction.values[0] === "identity_rules") {
        let rulesEmbed = new Discord.EmbedBuilder()
          .setColor("#00dfff")
          .setTitle("<:tl:1262585318171869195> The Laws Card TownLaw")
          .setDescription(`__** <:gulfbot_1222010640206528594:1272613590821769289>  

<:1OL_1rulesx1:1288375900840263736>   الاسم يكون بالانقليزي 

<:1OL_1rulesx1:1288375900840263736>  
يمنع تكرير الاسامي مثل \`\`\`\[ خالد بن خالد ] \`\`\`

<:1OL_1rulesx1:1288375900840263736> يمنع وضع اسم اباحي 

<:1OL_1rulesx1:1288375900840263736> يجب ان يكون تاريخ الميلاد لائق على صوتك 

<:1OL_1rulesx1:1288375900840263736> يمنع وضح اسم [ ابو ، ام ، ] 

<:1OL_1rulesx1:1288375900840263736> يجب عليك كتابة تاريخ الميلاد بهاذا الشكل 
{ 30/04/1996 } 

<:1OL_1rulesx1:1288375900840263736> يجب عليك وضع الجنسية من احد مدن قراند بالانقليزي 

<:1OL_1rulesx1:1288375900840263736> يُمنع تقليد أسماء الشخصيات.

TownLaw Managament Team <:emoji_121:1252954003013242921> 
**__`)
          .setFooter({ text: " TLRP Dev", iconURL: interaction.guild.iconURL() });

        await interaction.reply({ embeds: [rulesEmbed], ephemeral: true }); // الرسالة تظهر للمستخدم فقط
      }
    });
  }
};