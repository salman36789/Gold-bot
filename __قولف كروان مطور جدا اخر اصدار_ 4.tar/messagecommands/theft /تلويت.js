const userBase = require('../../Models/userBase'),
    guildBase = require('../../Models/guildBase'),
    Discord = require('discord.js');

module.exports = {
    name: `تلويت`,
    aliases: ["فشخ"],
    run: async (client, message, args) => {
        const target = message.mentions.users.first();
        if (!target) return message.reply({ content: `:x: | يجب عليك منشن الشخص الذي تريد سرقته` });

        let db = await guildBase.findOne({ guild: message.guild.id });
        if (!db) {
            db = new guildBase({ guild: message.guild.id });
            await db.save();
        }

        let checkUser = db.joins.find(c => c.user === message.author.id);
        let checkTarget = db.joins.find(c => c.user === target.id);
        if (!checkUser || !checkTarget) return message.reply({
            content: `:x: | يجب على كلاكما تسجيل الدخول أولاً`
        });

        let targetData = await userBase.findOne({ guild: message.guild.id, user: target.id });
        if (!targetData) {
            targetData = new userBase({ guild: message.guild.id, user: target.id });
            await targetData.save();
        }
        targetData = targetData[checkTarget.character];

        // التحقق مما إذا كان الهدف مكلبش
        if (!targetData.clamped) return message.reply({
            content: `:x: | لا يمكنك سرقة هذا الشخص لأنه **غير مكلبش**!`
        });

        const allinvs = [], max = 5, inv = [...targetData.inv.sort((a, b) => b.count - a.count)];
        if (inv.length <= 0) return message.reply({
            content: `:x: | حقيبة الشخص فارغة`
        });

        while (inv.length) {
            allinvs.push(inv.splice(0, max));
        }

        function generateEmbed(page) {
            return new Discord.EmbedBuilder()
                .setColor("#00dfff")
                .setThumbnail(message.guild.iconURL({ dynamic: true }))
                .setDescription(`**<:employeemanalt:1328359209070493837> - ID <@${target.id}>

${allinvs[page].map((value, i) => `${i + 1} | ${value.name}\n- Amount | ${value.count}`).join("\n\n")}**`);
        }


        var currentPage = 0;
        let row = new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder()
                .setCustomId("back")
                .setStyle("Secondary")
                .setEmoji("<a:OL_BLeft1:1288390502986813511>")
                .setDisabled(currentPage == 0),

            new Discord.ButtonBuilder()
                .setCustomId("next")
                .setStyle("Secondary")
                .setDisabled(targetData.inv.length <= max)
                .setEmoji("<a:OL_Aright:1288390501048909834>")
        );

        let msg = await message.reply({
            embeds: [generateEmbed(currentPage)],
            components: [row]
        });

        const collector = msg.createMessageComponentCollector({ componentType: Discord.ComponentType.Button, time: 120000 });
        collector.on('collect', async (i2) => {
            if (i2.user.id != message.author.id) return;
            await i2.deferUpdate();

            if (i2.customId === 'back') currentPage -= 1;
            else if (i2.customId === 'next') currentPage += 1;

            await row.components[0].setDisabled(currentPage === 0);
            await row.components[1].setDisabled(currentPage === allinvs.length - 1);

            await msg.edit({
                embeds: [generateEmbed(currentPage)],
                components: [row]
            });
        });

        collector.on('end', () => msg.delete());

        const selectMenu = new Discord.SelectMenuBuilder()
            .setCustomId('select')
            .setPlaceholder('اختر العناصر التي تريد سرقتها')
            .setMinValues(1)
            .setMaxValues(2)
            .addOptions(allinvs[currentPage].map(item => ({
                label: item.name,
                description: `الكمية: ${item.count}`,
                value: item.name
            })));

        const selectRow = new Discord.ActionRowBuilder().addComponents(selectMenu);
        await message.reply({ content: 'اختر العناصر التي تريد سرقتها:', components: [selectRow] });

        const selectCollector = message.channel.createMessageComponentCollector({ componentType: Discord.ComponentType.SelectMenu, time: 60000 });

        selectCollector.on('collect', async (i) => {
            if (i.user.id !== message.author.id) return;
            await i.deferUpdate();

            let userData = await userBase.findOne({ guild: message.guild.id, user: message.author.id });
            if (!userData) {
                userData = new userBase({ guild: message.guild.id, user: message.author.id });
                await userData.save();
            }
            userData = userData[checkUser.character];

            const stolenItems = i.values;
            const stolenItemsDetails = [];

            stolenItems.forEach(itemName => {
                const itemIndex = targetData.inv.findIndex(item => item.name === itemName);
                if (itemIndex !== -1) {
                    const item = targetData.inv[itemIndex];

                    if (item.count > 1) {
                        item.count -= 1;
                        stolenItemsDetails.push(`${item.name} (1)`);
                        const userItemIndex = userData.inv.findIndex(userItem => userItem.name === item.name);
                        if (userItemIndex !== -1) userData.inv[userItemIndex].count += 1;
                        else userData.inv.push({ name: item.name, count: 1 });
                    } else {
                        targetData.inv.splice(itemIndex, 1);
                        stolenItemsDetails.push(`${item.name} (1)`);
                        userData.inv.push({ name: item.name, count: 1 });
                    }
                }
            });

            await userBase.updateOne({ guild: message.guild.id, user: message.author.id }, { [checkUser.character]: userData });
            await userBase.updateOne({ guild: message.guild.id, user: target.id }, { [checkTarget.character]: targetData });

            const embed = new Discord.EmbedBuilder()
                .setColor("#00FF00")
                .setTitle("تم السرقة بنجاح!")
                .setDescription(`**تم سرقة العناصر التالية من ${target.username}:**\n\n${stolenItemsDetails.join("\n")}`)
                .setFooter({ text: `بواسطة: ${message.author.username}` });

            await message.reply({ embeds: [embed] });

            selectCollector.stop();
        });

        selectCollector.on('end', collected => {
            if (collected.size === 0) message.reply({ content: 'انتهى الوقت ولم يتم اختيار أي عناصر.' });
        });
    }
};
