const {
    ActionRowBuilder,
    StringSelectMenuBuilder,
    EmbedBuilder,
} = require('discord.js');
const userBase = require('../../Models/userBase');
const { thefts } = require('../../thefts.json');

module.exports = {
    name: 'سرقة',
    run: async (client, message, args) => {
        if (!thefts || thefts.length === 0) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setDescription('**لا يوجد أنواع سرقات متوفرة حاليًا.**')
                        .setColor('#00dfff'),
                ],
            });
        }

        const theftOptions = thefts.map((theft) => ({
            label: theft.name,
            description: theft.description || 'Choose this type of robbery .',
            value: theft.name.toLowerCase(),
            emoji: "<:Tl:1256478712711479418>",
        }));

        const selectMenu = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('theft_type')
                .setPlaceholder('Choose the robbery')
                .addOptions(theftOptions)
        );

        await message.channel.send({
            embeds: [
                new EmbedBuilder()
                    .setDescription('**<:Tl:1256478712711479418> - From here , you can start carrying out your illegal theft missions taking your time to plan and execute each step carefully as you move forward .**')
                .setColor('#00dfff')

                .setImage('https://media.discordapp.net/attachments/1337493195029872670/1338879733395619850/IMG_4599.jpg?ex=67acb06b&is=67ab5eeb&hm=d372681d06e2a019ceaa698310a1345c53927e68a43513d00d66879149cc8dcc&'),
            ],
            components: [selectMenu],
        });
    },
};