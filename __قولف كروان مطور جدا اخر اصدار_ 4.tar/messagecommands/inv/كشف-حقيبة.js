const userBase = require('../../Models/userBase')
    , guildBase = require('../../Models/guildBase')
    , Discord = require('discord.js')

module.exports = {
    name: `كشف-حقيبة`,
    run: async (client, message, args) => {
        let db = await guildBase.findOne({ guild: message.guild.id })
        if (!db) {
            db = new guildBase({ guild: message.guild.id })
            await db.save();
        }

        let check = db.joins.find(c => c.user === message.author.id)
        if (!check) return message.reply({
            content: `:x: | يجب تسجيل دخولك اولا حتى تتمكن من استخدام هذا الامر`
        })

        let data = await userBase.findOne({ guild: message.guild.id, user: message.author.id })
        if (!data) {
            data = new userBase({ guild: message.guild.id, user: message.author.id })
            await data.save();
        }

        data = data[check.character]

        if (data.clamped) return message.reply({
            content: `**<:1OL_1warrn:1252516293379231764> - انت مكلبش لايمكنك استخدام هذا الامر**`
        })

        let user = message.mentions.users.first()
        if (!user) return message.reply({
            content: `:x: | يجب عليك ذكر الشخص الذي تريد كشف حقيبته`
        })

        let check2 = db.joins.find(c => c.user === user.id)
        if (!check2) return message.reply({
            content: `:x: | لا يمكنك كشف حقيبة ${user} لانه غير مسجل دخول`
        })

        let row = new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder()
                .setCustomId(`showInvAccept`)
                .setLabel("قبول الكشف")
                .setStyle("Success"),

            new Discord.ButtonBuilder()
                .setCustomId(`showInvReject`)
                .setLabel("رفض الكشف")
                .setStyle("Danger")
        )

        let embed = new Discord.EmbedBuilder()
            .setColor("#00dfff")
            .setImage("https://i.postimg.cc/jSsYsncH/Whats-App-Image-2025-01-14-at-7-41-43-PM.jpg")
            .setDescription(`**<:1OL_1warrn:1252516293379231764> - شخص ما يريد كشف حقيبتك 

<:group2:1328358692676046879> - الشخص | ${message.author}

<:tl:1262585314787201034> - الشخصية | ${check2.character === "c1" ? "1" : "2"}

<:1OL_1mute3:1288375881907048490> - ملاحظة هامة | في حال تم القبول سيتم كشف حقيبتك للشخص !**`)

        let msg = await user.send({
            embeds: [embed],
            components: [row]
        })

        let msg2 = await message.reply({
            content: `:white_check_mark: | تم إرسال طلب كشف الحقيبة إلي ${user}`
        })

        const collector = msg.createMessageComponentCollector({ componentType: Discord.ComponentType.Button, time: 20000 });
        collector.on('collect', async interaction => {
            if (interaction.customId === "showInvAccept") {
                let userData = await userBase.findOne({ guild: message.guild.id, user: user.id })
                if (!userData) return msg2.edit({
                    content: `:x: | تم قبول كشف الحقيبة .. لكن ${user} لا يملك أي اغراض داخل الحقيبة`
                })

                userData = userData[check2.character]

                await interaction.update({
                    components: [],
                    embeds: [Discord.EmbedBuilder.from(interaction.message.embeds[0]).setDescription(`**:white_check_mark: | تم كشف حقيبتك**`)]
                })

                const allinvs = [], max = 5, inv = [...userData.inv.sort((a, b) => b.count - a.count)];

                if (inv.length <= 0) return msg2.edit({
                    content: `:x: | تم قبول كشف الحقيبة .. لكن ${user} لا يملك أي اغراض داخل الحقيبة`
                })

                while (inv.length) {
                    allinvs.push(inv.splice(0, max));
                }

                function generateEmbed(page) {
                    const embed = new Discord.EmbedBuilder()
                        .setColor("#00dfff")
                        .setThumbnail(message.guild.iconURL({ dynamic: true }))
                        .setDescription(`**<:employeemanalt:1328359209070493837> - Name | ${userData.id.first}

${allinvs[page].map((value, i) => `${i + 1} | ${value.name}\n- Amount | ${value.count}`).join("\n\n")}**`)

                    return embed;
                }

                var currentPage = 0;
                let row = new Discord.ActionRowBuilder().addComponents(
                    new Discord.ButtonBuilder()
                        .setCustomId("back")
                        .setStyle("Secondary")
                        .setEmoji("<a:OL_BLeft1:1288390502986813511>")
                        .setDisabled(currentPage == 0),

                    new Discord.ButtonBuilder()
                        .setCustomId("next")
                        .setStyle("Secondary")
                        .setDisabled(userData.inv.length <= max)
                        .setEmoji("<a:OL_Aright:1288390501048909834>")
                )

                await msg2.edit({
                    content: null,
                    embeds: [generateEmbed(currentPage)],
                    components: [row]
                })

                setTimeout(async function(){
                    msg2.delete();
                    await message.delete();
                }, 10000)

                const collector2 = msg2.createMessageComponentCollector({ componentType: Discord.ComponentType.Button, time: 120000 });
                collector2.on('collect', async (i2) => {
                    if (i2.user.id != message.author.id) return;

                    await i2.deferUpdate();

                    if (i2.customId === 'back') {
                        currentPage -= 1;

                        if (currentPage < 0) currentPage = allinvs.length - 1;
                    } else if (i2.customId === 'next') {
                        currentPage += 1;

                        if (currentPage === allinvs.length) currentPage = 0;
                    }

                    await row.components[0].setDisabled(currentPage === 0);
                    await row.components[1].setDisabled(currentPage === allinvs.length - 1);

                    await msg2.edit({
                        embeds: [generateEmbed(currentPage)],
                        components: [row]
                    });
                });
            } else {
                msg2.edit({
                    content: `:x: | تم رفض كشف الحقيبة من قبل ${user}`
                })

                await interaction.update({
                    components: [],
                    embeds: [Discord.EmbedBuilder.from(interaction.message.embeds[0]).setDescription(`**:white_check_mark: | تم إلغاء عملية كشف حقيبتك**`)]
                })
            }
        })

        collector.on('end', async collected => {
            if (collected.size > 0) return;

            msg2.edit({
                content: `:x: | فشل كشف الحقيبة بسبب عدم قبول أو رفض العضو`
            })

            await msg.edit({
                components: [],
                embeds: [Discord.EmbedBuilder.from(msg.embeds[0]).setDescription(`**:white_check_mark: | تم إلغاء عملية كشف حقيبتك**`)]
            })
        });
    }
};