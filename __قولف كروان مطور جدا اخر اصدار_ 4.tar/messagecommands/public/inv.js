const userBase = require('../../Models/userBase')
    , guildBase = require('../../Models/guildBase')
    , Discord = require('discord.js')

module.exports = {
    name: `inv`,
    aliases: ["حقيبتي"],
    run: async (client, message, args) => {
        let db = await guildBase.findOne({ guild: message.guild.id })
        if (!db) {
            db = new guildBase({ guild: message.guild.id })
            await db.save();
        }

        let check = db.joins.find(c => c.user === message.author.id)
        if (!check) return message.reply({
            content: `:x: | يجب تسجيل دخولك اولا حتى تتمكن من استخدام هذا الامر`
        })

        let data = await userBase.findOne({ guild: message.guild.id, user: message.author.id })
        if (!data) {
            data = new userBase({ guild: message.guild.id, user: message.author.id })
            await data.save();
        }

        data = data[check.character]

        if(data.clamped) return message.reply({
            content: `**<:1OL_1warrn:1252516293379231764> - انت مكلبش لايمكنك استخدام هذا الامر**`
        })

        const allinvs = [], max = 5, inv = [...data.inv.sort((a, b) => b.count - a.count)];

        if (inv.length <= 0) return message.reply({
            content: `:x: | الشخصية ${check.character === "c1" ? "الاولى" : "الثانية"} لا تملك اغراض داخل الحقيبة`,
            components: []
        })

        while (inv.length) {
            allinvs.push(inv.splice(0, max));
        }

        function generateEmbed(page) {
            const embed = new Discord.EmbedBuilder()
                .setColor("#00dfff")
                .setThumbnail(message.guild.iconURL({ dynamic: true }))
                .setDescription(`**<:employeemanalt:1328359209070493837> - Name | ${data.id.first}

${allinvs[page].map((value, i) => `${i + 1} | ${value.name}\n- Amount | ${value.count} `).join("\n\n")}**`)

            return embed;
        }

        var currentPage = 0;
        let row = new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder()
                .setCustomId("back")
                .setStyle("Secondary")
                .setEmoji("<a:OL_BLeft1:1288390502986813511>")
                .setDisabled(currentPage == 0),

            new Discord.ButtonBuilder()
                .setCustomId("next")
                .setStyle("Secondary")
                .setDisabled(data.inv.length <= max)
                .setEmoji("<a:OL_Aright:1288390501048909834>")
        )

        let msg = await message.reply({
            embeds: [generateEmbed(currentPage)],
            components: [row]
        })

        const collector = msg.createMessageComponentCollector({ componentType: Discord.ComponentType.Button, time: 120000 });
        collector.on('collect', async (i2) => {
            if (i2.user.id != message.author.id) return;

            await i2.deferUpdate();

            if (i2.customId === 'back') {
                currentPage -= 1;

                if (currentPage < 0) currentPage = allinvs.length - 1;
            } else if (i2.customId === 'next') {
                currentPage += 1;

                if (currentPage === allinvs.length) currentPage = 0;
            }

            await row.components[0].setDisabled(currentPage === 0);
            await row.components[1].setDisabled(currentPage === allinvs.length - 1);

            await msg.edit({
                embeds: [generateEmbed(currentPage)],
                components: [row]
            });
        });

        collector.on('end', collected => {
            if (collected.size > 0) return;

            msg.delete();
        });
    }
};