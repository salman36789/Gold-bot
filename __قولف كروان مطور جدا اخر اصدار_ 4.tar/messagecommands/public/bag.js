const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  AttachmentBuilder,
  ComponentType,
  PermissionsBitField,
} = require('discord.js');
const fs = require('fs');
const path = require('path');
const { createCanvas, loadImage } = require('canvas');
const userBase = require('../../Models/userBase');
const guildBase = require('../../Models/guildBase');

module.exports = {
  name: 'bag',
  run: async (client, message, args) => {
    try {
      // التحقق من الصلاحيات
      if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return message.reply('لا تملك صلاحية لاستخدام هذا الأمر.');
      }

      // إنشاء الزر
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('showInventory')
          .setLabel('Bag')
          .setStyle(ButtonStyle.Primary)
      );

      // إنشاء الرسالة الأساسية
      const embed = new EmbedBuilder()
        .setColor('#0099ff')
        .setTitle('Bag')
        .setDescription('**The Bag Control Panel <:emoji_286:1333040124908273686>**')
        .setTimestamp()
        .setFooter({ text: 'Baggage system', iconURL: null });
       
      const sentMessage = await message.channel.send({
        embeds: [embed],
        components: [row],
      });
        
        

      // إنشاء "Collector" لجمع الأزرار
      const filter = (i) => i.customId === 'showInventory' && i.user.id === message.author.id;
      const collector = sentMessage.createMessageComponentCollector({
        filter,
        componentType: ComponentType.Button,
        time: 120000,
      });

      collector.on('collect', async (interaction) => {
        await interaction.deferReply({ ephemeral: true });

        // التحقق من قاعدة البيانات
        let db = await guildBase.findOne({ guild: message.guild.id });
        if (!db) {
          db = new guildBase({ guild: message.guild.id });
          await db.save();
        }

        let check = db.joins.find((c) => c.user === message.author.id);
        if (!check) {
          return interaction.followUp({
            content: `:x: | يجب تسجيل دخولك اولا حتى تتمكن من استخدام هذا الامر`,
            ephemeral: true,
          });
        }

        let data = await userBase.findOne({
          guild: message.guild.id,
          user: message.author.id,
        });
        if (!data) {
          data = new userBase({
            guild: message.guild.id,
            user: message.author.id,
          });
          await data.save();
        }

        data = data[check.character];

        if (data.clamped) {
          return interaction.followUp({
            content: `**<:1OL_1warrn:1252516293379231764> - انت مكلبش لايمكنك استخدام هذا الامر**`,
            ephemeral: true,
          });
        }

        const inv = [...data.inv.sort((a, b) => b.count - a.count)];

        if (inv.length <= 0) {
          return interaction.followUp({
            content: `:x: | الشخصية ${
              check.character === 'c1' ? 'الاولى' : 'الثانية'
            } لا تملك اغراض داخل الحقيبة`,
            ephemeral: true,
          });
        }

        // إنشاء الصورة
        const baseImagePath = path.join(__dirname, 'ba.png');
        if (!fs.existsSync(baseImagePath)) {
          console.error('الصورة الأساسية غير موجودة في المسار المحدد:', baseImagePath);
          return interaction.followUp({
            content: 'The base image does not exist. Please check the path.',
            ephemeral: true,
          });
        }

        const baseImage = await loadImage(baseImagePath);
        const canvas = createCanvas(baseImage.width, baseImage.height);
        const ctx = canvas.getContext('2d');

        ctx.drawImage(baseImage, 0, 0);

        const defaultFontSize = 13;
        ctx.font = `${defaultFontSize}px Arial`;
        ctx.fillStyle = '#FFFFFF';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';

        const imageMap = {
  'مفتاح السيارة': 'key.png',
  'سيف': 'sword.png',
  'تفاحة': 'apple.png',
  'درع': 'shield.png'
};

const itemImages = {};

async function loadItemImages() {
  for (const key in imageMap) {
    itemImages[key] = await loadImage(imageMap[key]);
  }
}

await loadItemImages(); // تحميل الصور قبل الرسم

inv.forEach((item, index) => {
  const row = Math.floor(index / 7);
  const col = index % 7;
  const x = 45 + col * 85;
  const y = 80 + row * 85;

  if (itemImages[item.name]) {
    ctx.drawImage(itemImages[item.name], x + 10, y + 10, 60, 60); // رسم الصورة
  } else {
    ctx.font = `${defaultFontSize}px Arial`;
    ctx.fillText(item.name, x + 85 / 2, y + 85 / 2);
  }

  if (item.count > 1) {
    ctx.font = `${defaultFontSize - 5}px Arial`;
    ctx.fillText(`x${item.count}`, x + 85 / 2, y + 70);
  }
});

        const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'bag.png' });
        await interaction.followUp({ files: [attachment], ephemeral: true });
      });

      // حدث حذف الرسالة
      client.on('messageDelete', async (deletedMessage) => {
        if (deletedMessage.id === sentMessage.id) {
          try {
            const newMessage = await message.channel.send({
              embeds: [embed],
              components: [row],
            });
            sentMessage.id = newMessage.id;
          } catch (err) {
            console.error('خطأ أثناء إعادة إرسال الرسالة:', err);
          }
        }
      });
    } catch (err) {
      console.error('خطأ في استرجاع المشتريات من قاعدة البيانات:', err);
      return message.reply('حدث خطأ أثناء استرجاع بيانات المشتريات.');
    }
  },
};
