const Discord = require('discord.js');
const userBase = require('../../Models/userBase');
const guildBase = require('../../Models/guildBase');

module.exports = {
    name: 'send-message22',
    run: async (client, message, args) => {
        let db = await guildBase.findOne({ guild: message.guild.id });

        if (!db) {
            db = new guildBase({ guild: message.guild.id });
            await db.save();
        }

        // الرتبة المطلوبة للتفاعل مع الأزرار
        const requiredRole = "1337726870199861322"; // ضع هنا ID الرتبة المطلوبة

        // التحقق من أن المستخدم لديه الرتبة المطلوبة
        if (!message.member.roles.cache.has(requiredRole)) {
            return message.reply({ content: "❌ ليس لديك الصلاحية لتقديم طلب وظيفة.", ephemeral: true });
        }

        const embed = new Discord.EmbedBuilder()
            .setColor("#00dfff")
            .setTitle("Choose a Job")
        .setImage("https://media.discordapp.net/attachments/1336437701527732324/1337776428376395836/KBdbtedwIx.jpg?ex=67a8ace3&is=67a75b63&hm=39c0a20bfec6a2035e18f137da6ba367f6f9599c2d585f750c523a29dcfa680b&")
            .setDescription("<:1OL_1online:1252516288429953038> - Please select a job below to apply:");

        const row = new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder().setCustomId("pizza").setLabel("Delivery Pizza").setEmoji("🍕").setStyle("Primary"),
            new Discord.ButtonBuilder().setCustomId("postman").setLabel("Postman").setEmoji("📦").setStyle("Primary"),
            new Discord.ButtonBuilder().setCustomId("taxi").setLabel("Taxi").setEmoji("🚖").setStyle("Primary")
        );

        let msg = await message.reply({ embeds: [embed], components: [row] });

        const collector = msg.createMessageComponentCollector({ componentType: Discord.ComponentType.Button });

        collector.on('collect', async (i) => {
            // التحقق من أن المستخدم لديه الرتبة المطلوبة
            if (!i.member.roles.cache.has(requiredRole)) {
                return i.reply({ content: "❌ ليس لديك الصلاحية لتقديم طلب وظيفة.", ephemeral: true });
            }

            const modal = new Discord.ModalBuilder()
                .setCustomId(`job_application_${i.customId}`)
                .setTitle("Job Application")
                .addComponents(
                    new Discord.ActionRowBuilder().addComponents(
                        new Discord.TextInputBuilder()
                            .setCustomId("court_image")
                            .setLabel("Court Image Link")
                            .setStyle(Discord.TextInputStyle.Short)
                            .setRequired(true)
                    )
                );

            await i.showModal(modal);
        });

        client.on('interactionCreate', async (interaction) => {
            if (!interaction.isModalSubmit()) return;
            if (!interaction.customId.startsWith("job_application_")) return;

            const courtImage = interaction.fields.getTextInputValue("court_image");
            const job = interaction.customId.replace("job_application_", "");
            const jobChannel = message.guild.channels.cache.get("1343210820485644319"); // ضع ID القناة هنا
            const roleApprover = message.guild.roles.cache.get("1328570412866736166"); // ضع ID رتبة الموافقة هنا

            const jobRoles = {
                pizza: "1334366962444271649", // ضع ID رتبة وظيفة بيتزا هنا
                postman: "1296796640824397865", // ضع ID رتبة وظيفة البريد هنا
                taxi: "1328570491220394094" // ضع ID رتبة وظيفة التاكسي هنا
            };

            await interaction.reply({ content: "✅ تم إرسال التقديم بنجاح", ephemeral: true });

            const jobEmbed = new Discord.EmbedBuilder()
                .setColor("#00dfff")
                .setTitle("New Job Application")
                .setDescription(`**User:** ${interaction.user}
                **Job:** ${job}
                **Court Image:** [Click Here](${courtImage})`)
                .setImage(courtImage);

            const row = new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder().setCustomId("accept").setLabel("Accept").setStyle("Success"),
                new Discord.ButtonBuilder().setCustomId("deny").setLabel("Deny").setStyle("Danger")
            );

            let jobMsg = await jobChannel.send({ embeds: [jobEmbed], components: [row] });

            const jobCollector = jobMsg.createMessageComponentCollector({ componentType: Discord.ComponentType.Button });

            jobCollector.on('collect', async (i) => {
                if (!i.member.roles.cache.has(roleApprover.id)) return;

                if (i.customId === "accept") {
                    const jobRole = message.guild.roles.cache.get(jobRoles[job]);
                    if (jobRole) await interaction.member.roles.add(jobRole);
                    await interaction.user.send(`تم قبولك في وظيفة ${job}`);

                    const updatedRow = new Discord.ActionRowBuilder().addComponents(
                        new Discord.ButtonBuilder().setCustomId("accept").setLabel("Accept").setStyle("Success").setDisabled(true),
                        new Discord.ButtonBuilder().setCustomId("deny").setLabel("Deny").setStyle("Danger").setDisabled(true)
                    );

                    await jobMsg.edit({ components: [updatedRow] });
                    await i.reply({ content: "✅ تم قبول الشخص بنجاح", ephemeral: true });
                } else {
                    await interaction.user.send(`تم رفضك في وظيفة ${job}`);
                }
            });
        });
    }
};