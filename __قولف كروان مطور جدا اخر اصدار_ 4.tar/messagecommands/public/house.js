const userBase = require('../../Models/userBase')
    , guildBase = require('../../Models/guildBase')
    , Discord = require('discord.js')

module.exports = {
    name: `house1`,
    aliases: ["1house"],
    run: async (client, message, args) => {
        let db = await guildBase.findOne({ guild: message.guild.id })
        if (!db) {
            db = new guildBase({ guild: message.guild.id })
            await db.save();
        }

        let check = db.joins.find(c => c.user === message.author.id)
        if (!check) return message.reply({
            content: `:x: | يجب تسجيل دخولك اولا حتى تتمكن من استخدام هذا الامر`
        })

        let data = await userBase.findOne({ guild: message.guild.id, user: message.author.id })
        if (!data) {
            data = new userBase({ guild: message.guild.id, user: message.author.id })
            await data.save();
        }

        data = data[check.character]

        if (data.clamped) return message.reply({
            content: `**<:1OL_1warrn:1252516293379231764> - انت مكلبش لايمكنك استخدام هذا الامر**`
        })

        if(data.builds.length <= 0) return message.reply({
            content: `:x: | الشخصية ${check.character === "c1" ? "الاولى" : "الثانية"} لا تملك عقارات`
        })

        let embed = new Discord.EmbedBuilder()
        .setColor("#00dfff")
        .setImage("https://i.imgur.com/19vVsy8.png")
        .setTitle("<:LOOCC1:1288390496905072673> - TOWN LAW Real Estate .")
        .setDescription(`**__Choose your own house from bottom button :arrow_down: __**`)

        let row = new Discord.ActionRowBuilder().addComponents(
            new Discord.StringSelectMenuBuilder()
                .setCustomId(`own_builds_menu_${message.author.id}`)
                .setMaxValues(1)
                .setPlaceholder("Select from your own houses")
                .addOptions(data.builds.map((data, i) => { return { emoji: "🏠", label: `${data.name}`, value: `${i}` } }))
        )

        await message.reply({
            embeds: [embed],
            components: [row]
        })
    }
};