const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ComponentType } = require('discord.js');

module.exports = {
    name: 'help',
    aliases: ['help'],
    run: async (client, message, args) => {
        try { 
            const helpEmbed = new EmbedBuilder()
                .setColor('#00dfff')
                .setTitle('قائمة المساعدة')
            .setImage("https://media.discordapp.net/attachments/1336437701527732324/1337776428376395836/KBdbtedwIx.jpg?ex=67a8ace3&is=67a75b63&hm=39c0a20bfec6a2035e18f137da6ba367f6f9599c2d585f750c523a29dcfa680b&")
                .setDescription('قم بأختيار فئة الاوامر التي تريد رؤيتها');

            const selectMenu = new StringSelectMenuBuilder()
                .setCustomId('helpMenu')
                .setPlaceholder('Select a Category')
                .addOptions([
                    { label: 'أوامر التعيين', value: 'assignCommands', emoji: '<a:OL_Aload:1343640574506569861>' },
                    { label: 'أوامر الأعضاء', value: 'memberCommands', emoji: '<a:OL_Aload:1343640574506569861>' },
                    { label: 'أوامر الإدارة', value: 'adminCommands', emoji: '<a:OL_Aload:1343640574506569861>' },
                    { label: 'اوامر المسؤولين', value: 'managerCommands', emoji: '<a:OL_Aload:1343640574506569861>' },
                ]);

            const row = new ActionRowBuilder().addComponents(selectMenu);

            const sentMessage = await message.channel.send({ embeds: [helpEmbed], components: [row] });

            const collector = sentMessage.createMessageComponentCollector({
                componentType: ComponentType.StringSelect,
            });

            collector.on('collect', async (interaction) => {
                if (interaction.user.id !== message.author.id) return;

                let updatedEmbed;
                switch (interaction.values[0]) {
                    case 'assignCommands':
                        updatedEmbed = EmbedBuilder.from(helpEmbed)
                            .setTitle('أوامر التعيين')
                            .setDescription(`
                                \`-send-message\` - **لاظهار النظام الخاصه ب الشخصيات (CHARACTER)**
                                \`-send-message2\` - **لاظهار لوحة التحكم الخاصة ب الرحلات**
                                \`-send-message3\` - **لاظهار التكتات**
                                \`-send-message4\` - **لاظهار التحكم ب البنك**
                                \`-send-message5\` - **لاظهار الstore الخاص ب السرقات**
                                \`-send-message6\` - **لاظهار التصنيع / التجميع / التطوير**
                                \`-send-message7\` - **لاظهار اللوحة الخاصة ب حالة السيرفر**
                                \`-send-message8\` - **لاظهار ايكيا**
                                \`-send-message10\` - **لاظهار اللوحة الخاصة ب الإنعاش**
                                \`-send-message11\` - **لاظهار اللوحة الخاصة ب الجوال / الرسائل / جهات الاتصال**
                                \`-send-message12\` - **لاظهار البيوت و الشقق**
                                \`-send-message13\` - **لاظهار الكراج الخاص ب السيارات**
                                \`-send-message14\` - **Storage**
                                \`-send-message15\` - **Storage**
                            `);
                        break;
                    case 'memberCommands':
                        updatedEmbed = EmbedBuilder.from(helpEmbed)
                            .setTitle('أوامر الأعضاء')
                            .setDescription(`
                                \`-inv\` - **لكشف حقيبتك**
                                \`-give-item (@) (عدد الغرض) (اسم الغرض)\` - **لاعطاء شخص منتج من حقيبتك**
                                \`-use (عدد الغرض) (اسم الغرض)\` - **لاستخدام شيء بالحقيبة**
                                \`-كلبشة (@)\` - **لكلبشة شخص**
                                \`-فك-كلبشة (@)\` - **لفك كلبشة شخص**
                                \`-كسر-كلبشة\` - **لكسر الكلبشة**
                                \`-فك-كلبشات\` - **لفك كلبشة من خارج طرف اخر**
                                \`-كشف-حقيبة (@)\` - **لكشف حقيبة شخص**
                            `);
                        break;
                    case 'adminCommands':
                        updatedEmbed = EmbedBuilder.from(helpEmbed)
                            .setTitle('أوامر الإدارة')
                            .setDescription(`
                                \`-GMC\` - **استلام البلاغ للجمس مع نقطة تلقائيا**
                                \`-حضور-رحلة\` - **حضور رحلة**
                                \`(باقي الاوامر من -send-message)\` - **الأوامر المتواجده في send-message**
                            `);
                        break;
                    case 'managerCommands':
                        updatedEmbed = EmbedBuilder.from(helpEmbed)
                            .setTitle('اوامر المسؤولين')
                            .setDescription(`
                                \`-add-item (@) (رقم الشخصية) (عدد المنتج) (اسم المنتج)\` - **لإضافة منتج في حقيبة الشخص**
                                \`-remove-item (@) (رقم الشخصية) (عدد المنتج) (اسم المنتج)\` - **لإزالة منتج من حقيبة الشخص**
                                \`-reset-item (@) (رقم الشخصية)\` - **لتصفير حقيبة الشخص**
                                \`-reset-all-items (@منشن رتبه)\` - **لتصفير حقيبة الاشخاص**
                                \`-add-money (@) (رقم الشخصية) (المبلغ)\` - **لإضافة فلوس في بنك الشخص**
                                \`-remove-money (@) (رقم الشخصية) (المبلغ)\` - **لإزالة فلوس شخص**
                                \`-reset-money (@) (رقم الشخصية)\` - **لتصفير فلوس شخص**
                                \`-reset-all-money (@منشن رتبه)\` - **لتصفير فلوس الأعضاء**
                                \`-تشهير\` - **لرفع تشهير على شخص**
                                \`-خط\` - **لإرسال خط**
                                \`-حذف-هوية (@) (رقم الشخصية)\` - **لحذف هوية عضو**
                                \`-حذف-هويات\` - **لحذف هويات الأعضاء**
                            `);
                        break;
                }

                await interaction.update({ embeds: [updatedEmbed] });
            });

        } catch (error) {
            console.error(error);
            await message.channel.send({
                content: `حدث خطأ أثناء تنفيذ الأمر.\n\`\`\`${error.message}\`\`\``
            });
        }
    }
};