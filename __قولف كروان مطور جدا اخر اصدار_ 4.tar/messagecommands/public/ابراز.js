const Discord = require('discord.js')

    , guildBase = require('../../Models/guildBase')

    , userBase = require('../../Models/userBase')

module.exports = {

    name: `iden`,

    run: async (client, message, args, Discord) => {

        let db = await userBase.findOne({ guild: message.guild.id, user: message.author.id })

        if (!db) {

            return message.reply({

                content: `:x: | ليس لديك هوية`

            });

        }

        let character = db.c1.id ? "c1" : "c2"; // افترض أن العضو لديه شخصية واحدة فقط

        db = db[character]

        if (!db.id || Object.keys(db.id).length <= 0) {

            return message.reply({

                content: `:x: | ليس لديك هوية`

            });

        }

        let embed = new Discord.EmbedBuilder()

            .setColor("#00dfff")

            .setDescription(`**<:1OL_1ruless:1252516289457553456> - First Name | ${db.id.first}

<:1OL_1ruless:1252516289457553456> - Last Name | ${db.id.last}

<:1OL_1ruless:1252516289457553456> - Birthday | ${db.id.date}

<:1OL_1ruless:1252516289457553456> - Birth Place | ${db.id.place}

<:1OL_1ruless:1252516289457553456> - Gender | ${db.id.gender}**`)

            .setThumbnail(message.guild.iconURL())

            .setTimestamp();

        message.reply({

            embeds: [embed]

        });

    }

};