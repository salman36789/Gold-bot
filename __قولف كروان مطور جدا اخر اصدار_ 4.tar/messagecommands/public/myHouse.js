const userBase = require('../../Models/userBase')
    , guildBase = require('../../Models/guildBase')
    , Discord = require('discord.js')

module.exports = {
    name: `myHouse`,
    aliases: ["my-house", "myhouse", "عقاراتي"],
    run: async (client, message, args) => {
        let db = await guildBase.findOne({ guild: message.guild.id })
        if (!db) {
            db = new guildBase({ guild: message.guild.id })
            await db.save();
        }

        let check = db.joins.find(c => c.user === message.author.id)
        if (!check) return message.reply({
            content: `:x: | يجب تسجيل دخولك اولا حتى تتمكن من استخدام هذا الامر`
        })

        let data = await userBase.findOne({ guild: message.guild.id, user: message.author.id })
        if (!data) {
            data = new userBase({ guild: message.guild.id, user: message.author.id })
            await data.save();
        }

        data = data[check.character]

        if (data.clamped) return message.reply({
            content: `**<:1OL_1warrn:1252516293379231764> - انت مكلبش لايمكنك استخدام هذا الامر**`
        })

        const allbuilds = [], builds = [...data.builds];

        if (builds.length <= 0) return message.reply({
            content: `:x: | الشخصية ${check.character === "c1" ? "الاولى" : "الثانية"} لا تملك عقارات`,
            components: []
        })

        while (builds.length) {
            allbuilds.push(builds.splice(0, 1));
        }

        function generateEmbed(page) {
            let embed = new Discord.EmbedBuilder()
                .setColor("#00dfff")
                .setImage(`${allbuilds[page][0].image}`)
                .setDescription(`**<:LOOCC:1288390495030218754> — Apartment Name ( ${allbuilds[page][0].name} )
🚗 - Garage ( ${allbuilds[page][0].garage} )
📦 - Storage space ( ${allbuilds[page][0].storage} )
<:LOOCC1:1288390496905072673> - Apartment Location ( ${allbuilds[page][0].location} )
<:emoji_345:1329533433000755241> - Apartment Price ( ${allbuilds[page][0].price.toLocaleString("en-US")} ) **`)

            return embed;
        }

        var currentPage = 0;
        let row = new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder()
                .setCustomId("back")
                .setStyle("Secondary")
                .setEmoji("<a:OL_BLeft1:1288390502986813511>")
                .setDisabled(currentPage == 0),

            new Discord.ButtonBuilder()
                .setCustomId("next")
                .setStyle("Secondary")
                .setDisabled(data.builds.length <= 1)
                .setEmoji("<a:OL_Aright:1288390501048909834>")
        )

        let msg = await message.reply({
            embeds: [generateEmbed(currentPage)],
            components: [row]
        })

        const collector = msg.createMessageComponentCollector({ componentType: Discord.ComponentType.Button, time: 9999999 });
        collector.on('collect', async (i2) => {
            if (i2.user.id != message.author.id) return;

            if (i2.customId === 'back' || i2.customId === 'next' ) { await i2.deferUpdate() }

            if (i2.customId === 'back') {
                currentPage -= 1;

                if (currentPage < 0) currentPage = allbuilds.length - 1;
            } else if (i2.customId === 'next') {
                currentPage += 1;

                if (currentPage === allbuilds.length) currentPage = 0;
            }

            await row.components[0].setDisabled(currentPage === 0);
            await row.components[1].setDisabled(currentPage === allbuilds.length - 1);

            await msg.edit({
                embeds: [generateEmbed(currentPage)],
                components: [row]
            });
        });
    }
};