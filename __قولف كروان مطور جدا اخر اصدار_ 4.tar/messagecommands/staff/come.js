const guildBase = require("../../Models/guildBase");

module.exports = {
    name: `come`,
    run: async (client, message, args, Discord) => {
        let data = await guildBase.findOne({ guild: message.guild.id });
        if (!data) {
            data = new guildBase({ guild: message.guild.id });
            await data.save();
        }

        if (!data.staff_role) return message.reply({
            content: `:x: | خطأ بسبب عدم تعيين رتبة الإدارة`
        });

        if (!message.guild.roles.cache.get(data.staff_role)) return message.reply({
            content: `:x: | لا أستطيع إيجاد رتبة الإدارة داخل السيرفر`
        });

        if (!message.member.roles.cache.has(data.staff_role)) return message.reply({
            content: `:x: | ليس لديك صلاحيات لاستخدام هذا الأمر لأنك لست إداري`
        });

        let user = message.mentions.users.first();
        if (!user) return message.reply({
            content: `:x: | يجب عليك ذكر الشخص الذي تريد استدعاءه`
        });

        if (user.bot || user.id === message.author.id) return message.reply({
            content: `:x: | لا يمكنك استدعاء ${user}`
        });

        // الحصول على السبب من باقي المدخلات
        let reason = args.slice(1).join(" ");
        if (!reason) return message.reply({
            content: `:x: | يرجى تحديد سبب الاستدعاء`
        });

        user.send({
            embeds: [new Discord.EmbedBuilder()
                .setColor("#00dfff")
                .setDescription(`** - عزيزي العضو | ${user}

- تم طلبك من قبل الإداري | ${message.author}

- السبب | ${reason}

الرجاء الحضور إلى | ${message.channel}

متمنين لك التوفيق - **`)]
        }).then(() => {
            message.react("✅");
        }).catch(() => {
            message.react("❌");
        });
    }
};