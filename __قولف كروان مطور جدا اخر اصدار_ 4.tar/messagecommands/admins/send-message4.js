const Discord = require("discord.js")

module.exports = {
  name: `send-message4`,
  run: async (client, message, args) => {
    if (!message.member.permissions.has("8")) return;

    let embed = new Discord.EmbedBuilder()
      .setColor("#00dfff")
      .setImage("https://i.imgur.com/p9eySvl.png")
      .setDescription(`**<:tlrp_mazebank:1329017505179762699> - System Bank Maze .**`);
      
    let row = new Discord.ActionRowBuilder().addComponents(
        new Discord.ButtonBuilder()
        .setCustomId("bank_show")
        .setLabel("Money")
        .setEmoji("💰")
        .setStyle("Danger"),
        
        new Discord.ButtonBuilder()
        .setCustomId("bank_trans")
        .setLabel("Transfer")
        .setEmoji("🏦")
        .setStyle("Success"),

        new Discord.ButtonBuilder()
        .setCustomId("bank_add")
        .setLabel("Dep")
        .setEmoji("💵")
        .setStyle("Success"),

        new Discord.ButtonBuilder()
        .setCustomId("bank_get")
        .setLabel("With")
        .setEmoji("💳")
        .setStyle("Success")
    )

    message.delete();
    await message.channel.send({
      embeds: [embed],
      components: [row]
    })

  }
};