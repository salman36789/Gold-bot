const guildBase = require('../../Models/guildBase')
  , Blacklisted = require('../../Models/blacklisted')

module.exports = {
  name: `ازالة-مخالف`,
  run: async (client, message, args, Discord) => {
    let db = await guildBase.findOne({ guild: message.guild.id })
    if (!db) {
      db = new guildBase({ guild: message.guild.id })
      await db.save()
    }

    if (!db.blacklist) return message.reply({ content: `**⚠️ - لم يتم تعين رتبة المسؤولين عن البلاك ليست حتى الان**` })

    let role = message.guild.roles.cache.get(db.blacklist)
    if (!role) return message.reply({
      content: `**⚠️ - لا استطيع ايجاد رتبة مسؤولين البلاك ليست داخل السيرفر **`
    })

    if (!message.member.roles.cache.has(role.id)) return message.reply({
      content: `**⚠️ - هذا الامر متاح لمسؤولين بلاك ليست فقط**`
    })

    let user = message.mentions.members.first()
    if (!user) return message.reply({
      content: `**⚠️ - يجب عليك تحديد الشخص الذي تريد فك حظره**`
    })

    let blacklist_data = await Blacklisted.findOne({ guild: message.guild.id, user: user.user.id })
    if (!blacklist_data || user.user.bot) return message.reply({ content: `**⚠️ - ${user} لا يملك أي عقوبات**` })

    user.roles.cache.filter(role => role.name != "@everyone").map(role => role.id).forEach(async role => {
      await user.roles.remove(role).catch(() => 0)
    })

    /*blacklist_data.roles.forEach(role => {
      user.roles.add(role).catch(() => 0)
    })*/

    await Blacklisted.deleteMany({ guild: message.guild.id, user: user.user.id })

    await message.reply({ content: `:** <:tl:1262585330813636618> - You have unbanned this player . **` })

    let embed = new Discord.EmbedBuilder()
      .setColor("#00dfff")
      .setThumbnail(message.guild.iconURL())
      .setTimestamp()
      .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })

    const prv_message = embed.setDescription(`**<:1OL_1warrn:1252516293379231764> - UnBanned .

<:group2:1328358692676046879> - Player | ${user}

<:tl:1262585330813636618> - You have been unbanned .

\`\` TOWN LAW System . \`\`**`)

    await user.send({ embeds: [prv_message] }).catch(() => 0)

    let log_chat = message.guild.channels.cache.get(db.ban_log)
    if (log_chat) {
      const log_chatMSG = embed.setDescription(`**<:1OL_1warrn:1252516293379231764> - UnBanned Log .

<:group2:1328358692676046879> - Player | ${user}

<:1OL_manege:1275534310421565522> - From | ${message.author}

\`\` TOWN LAW System . \`\`**`)

      log_chat.send({ embeds: [log_chatMSG] })
    }
  }
};