const Discord = require("discord.js")

module.exports = {
  name: `send-message7`,
  run: async (client, message, args) => {
    if (!message.member.permissions.has("8")) return;

    let embed = new Discord.EmbedBuilder()
      .setColor("#00dfff")
      .setImage("https://i.postimg.cc/jSsYsncH/Whats-App-Image-2025-01-14-at-7-41-43-PM.jpg")
      .setDescription(`**<:1OL_1warrn:1252516293379231764> - Get Up Select The Server Status**`);

    let row = new Discord.ActionRowBuilder().addComponents(
        new Discord.ButtonBuilder()
        .setCustomId("status_online")
        .setLabel("Online")
        .setEmoji("<:Online:1250965894205669406>")
        .setStyle("Secondary"),
        
        new Discord.ButtonBuilder()
        .setCustomId("status_offline")
        .setLabel("Offline")
        .setEmoji("<:Obusy:1250965898697642016>")
        .setStyle("Secondary"),

        new Discord.ButtonBuilder()
        .setCustomId("status_busy")
        .setLabel("Busy")
        .setEmoji("<:Restart:1250965892901371946>")
        .setStyle("Secondary")
    )

    message.delete();
    await message.channel.send({
      embeds: [embed],
      components: [row]
    })

  }
};