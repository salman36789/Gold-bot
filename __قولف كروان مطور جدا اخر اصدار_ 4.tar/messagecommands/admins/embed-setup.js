const {

  ModalBuilder,

  TextInputBuilder,

  TextInputStyle,

  ActionRowBuilder,

  PermissionsBitField,

  EmbedBuilder,

  ButtonBuilder,

  ButtonStyle,

} = require("discord.js");

// تخزين القيم المدخلة

let embedData = {

  title: null,

  description: null,

  image: null,

  color: "#00dfff",

  footer: null,

};

module.exports = {

  name: "embed",

  run: async (client, message, args) => {

    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {

      return message.reply("🚫 **ليس لديك صلاحية استخدام هذا الأمر.**");

    }

    // التعليمات داخل إيمبد

    const instructionsEmbed = new EmbedBuilder()

      .setTitle("Embed Setup Instructions")

      .setDescription(`

        **قم بتحديد إعدادات الإيمبد باستخدام الأزرار أدناه:**

        **Set Embed:**

        - **حدد العنوان:**  

          (اكتب عنوان الإيمبد هنا)

        - **الوصف (رسالة الإيمبد):**  

          (اكتب وصف الإيمبد هنا)

        - **رابط الصورة:**  

          (لازم ترسل الصورة في شات مخفي وبعدها تنسخ الرابط حق الصورة وتحطه)

        - **لون الإيمبد:**  

          (اتركه ويجيك أحمر، بس إذا تبي تغير اللون حط كود اللون)

        - **حدد الرسالة:**  

          (حدد الرسالة اللي تكون تحت آخر شيء وبخط صغير بالإيمبد)

        **Send Embed:**

        - **حدد ID القناة:**  

          (بس الأرقام، وبتنرسل الرسالة مع @everyone)

        **Edit Embed:**

        - **حدد ID الرسالة:**  

          (قم بتعديل إيمبد موجود باستخدام ID الرسالة)

      `)

      .setColor("#00dfff")

      .setFooter({ text: "Town Law  System" });

    // الأزرار

    const setEmbedButton = new ButtonBuilder()

      .setCustomId("setEmbed")

      .setLabel("Set Embed")

      .setStyle(ButtonStyle.Primary);

    const sendEmbedButton = new ButtonBuilder()

      .setCustomId("sendEmbed")

      .setLabel("Send Embed")

      .setStyle(ButtonStyle.Success);

    const editEmbedButton = new ButtonBuilder()

      .setCustomId("editEmbed")

      .setLabel("Edit Embed")

      .setStyle(ButtonStyle.Secondary);

    const actionRow = new ActionRowBuilder().addComponents(

      setEmbedButton,

      sendEmbedButton,

      editEmbedButton

    );

    // إرسال التعليمات كإيمبد مع الأزرار

    await message.reply({

      embeds: [instructionsEmbed],

      components: [actionRow],

    });

    // التعامل مع التفاعلات

    client.on("interactionCreate", async (interaction) => {

      // التعامل مع زر "Set Embed"

      if (interaction.customId === "setEmbed" && interaction.isButton()) {

        const modal = new ModalBuilder()

          .setCustomId("embedModal")

          .setTitle("إعداد الإيمبد");

        const titleInput = new TextInputBuilder()

          .setCustomId("embedTitle")

          .setLabel("العنوان")

          .setPlaceholder("أدخل عنوان الإيمبد")

          .setStyle(TextInputStyle.Short)

          .setRequired(true);

        const descriptionInput = new TextInputBuilder()

          .setCustomId("embedDescription")

          .setLabel("الوصف")

          .setPlaceholder("أدخل وصف الإيمبد")

          .setStyle(TextInputStyle.Paragraph)

          .setRequired(true);

        const imageInput = new TextInputBuilder()

          .setCustomId("embedImage")

          .setLabel("رابط الصورة (اختياري)")

          .setPlaceholder("أدخل رابط الصورة")

          .setStyle(TextInputStyle.Short)

          .setRequired(false);

        const colorInput = new TextInputBuilder()

          .setCustomId("embedColor")

          .setLabel("لون الإيمبد (اختياري)")

          .setPlaceholder("مثل: #FF0000")

          .setStyle(TextInputStyle.Short)

          .setRequired(false);

        const footerInput = new TextInputBuilder()

          .setCustomId("embedFooter")

          .setLabel("التذييل (اختياري)")

          .setPlaceholder("أدخل نص التذييل")

          .setStyle(TextInputStyle.Short)

          .setRequired(false);

        modal.addComponents(

          new ActionRowBuilder().addComponents(titleInput),

          new ActionRowBuilder().addComponents(descriptionInput),

          new ActionRowBuilder().addComponents(imageInput),

          new ActionRowBuilder().addComponents(colorInput),

          new ActionRowBuilder().addComponents(footerInput)

        );

        await interaction.showModal(modal);

      }

      // التعامل مع إرسال النموذج

      if (interaction.customId === "embedModal" && interaction.isModalSubmit()) {

        embedData.title = interaction.fields.getTextInputValue("embedTitle");

        embedData.description =

          interaction.fields.getTextInputValue("embedDescription");

        embedData.image = interaction.fields.getTextInputValue("embedImage") || null;

        embedData.color =

          interaction.fields.getTextInputValue("embedColor") || "#00dfff";

        embedData.footer =

          interaction.fields.getTextInputValue("embedFooter") || null;

        // التحقق من صحة اللون

        if (!/^#([0-9A-F]{3}){1,2}$/i.test(embedData.color)) {

          return interaction.reply({

            content: "🚫 **يرجى إدخال لون صحيح بصيغة Hex مثل: #FF0000.**",

            ephemeral: true,

          });

        }

        // التحقق من صحة رابط الصورة

        if (embedData.image && !embedData.image.match(/^https?:\/\/.*\.(?:png|jpg|jpeg|gif)$/i)) {

          return interaction.reply({

            content: "🚫 **يرجى إدخال رابط صورة صحيح ينتهي بـ .png أو .jpg أو .gif.**",

            ephemeral: true,

          });

        }

        interaction.reply({

          content: `✅ **تم إعداد الإيمبد. يمكنك إرساله باستخدام زر الإرسال.**`,

          ephemeral: true,

        });

      }

      // التعامل مع زر "Send Embed"

      if (interaction.customId === "sendEmbed" && interaction.isButton()) {

        if (!embedData.title || !embedData.description) {

          return interaction.reply({

            content: "🚫 **يرجى إعداد الإيمبد باستخدام زر Set Embed أولاً.**",

            ephemeral: true,

          });

        }

        const modal = new ModalBuilder()

          .setCustomId("sendEmbedModal")

          .setTitle("إرسال الإيمبد");

        const channelIdInput = new TextInputBuilder()

          .setCustomId("channelId")

          .setLabel("ID القناة")

          .setPlaceholder("أدخل ID القناة")

          .setStyle(TextInputStyle.Short)

          .setRequired(true);

        modal.addComponents(

          new ActionRowBuilder().addComponents(channelIdInput)

        );

        await interaction.showModal(modal);

      }

      if (interaction.customId === "sendEmbedModal" && interaction.isModalSubmit()) {

        const channelId = interaction.fields.getTextInputValue("channelId");

        const channel = client.channels.cache.get(channelId);

        if (!channel || channel.type !== 0) {

          return interaction.reply({

            content: "🚫 **ID القناة غير صالح أو القناة ليست نصية.**",

            ephemeral: true,

          });

        }

        const embed = new EmbedBuilder()

          .setTitle(embedData.title)

          .setDescription(embedData.description)

          .setColor(embedData.color);

        if (embedData.image) embed.setImage(embedData.image);

        if (embedData.footer) embed.setFooter({ text: embedData.footer });

        await channel.send({ content: "@everyone", embeds: [embed] });

        interaction.reply({

          content: "✅ **تم إرسال الإيمبد بنجاح.**",

          ephemeral: true,

        });

      }

      // التعامل مع زر "Edit Embed"

      if (interaction.customId === "editEmbed" && interaction.isButton()) {

        const modal = new ModalBuilder()

          .setCustomId("editEmbedModal")

          .setTitle("تعديل الإيمبد");

        const messageIdInput = new TextInputBuilder()

          .setCustomId("messageId")

          .setLabel("ID الرسالة")

          .setPlaceholder("أدخل ID الرسالة")

          .setStyle(TextInputStyle.Short)

          .setRequired(true);

        const titleInput = new TextInputBuilder()

          .setCustomId("editEmbedTitle")

          .setLabel("العنوان")

          .setPlaceholder("أدخل عنوان الإيمبد الجديد")

          .setStyle(TextInputStyle.Short)

          .setRequired(true);

        const descriptionInput = new TextInputBuilder()

          .setCustomId("editEmbedDescription")

          .setLabel("الوصف")

          .setPlaceholder("أدخل وصف الإيمبد الجديد")

          .setStyle(TextInputStyle.Paragraph)

          .setRequired(true);

        const imageInput = new TextInputBuilder()

          .setCustomId("editEmbedImage")

          .setLabel("رابط الصورة الجديد (اختياري)")

          .setPlaceholder("أدخل رابط الصورة الجديد")

          .setStyle(TextInputStyle.Short)

          .setRequired(false);

        const colorInput = new TextInputBuilder()

          .setCustomId("editEmbedColor")

          .setLabel("لون الإيمبد الجديد (Hex, اختياري)")

          .setPlaceholder("مثل: #FF0000")

          .setStyle(TextInputStyle.Short)

          .setRequired(false);

        modal.addComponents(

          new ActionRowBuilder().addComponents(messageIdInput),

          new ActionRowBuilder().addComponents(titleInput),

          new ActionRowBuilder().addComponents(descriptionInput),

          new ActionRowBuilder().addComponents(imageInput),

          new ActionRowBuilder().addComponents(colorInput)

        );

        await interaction.showModal(modal);

      }

      // التعامل مع إرسال النموذج لتعديل الإيمبد

      if (interaction.customId === "editEmbedModal" && interaction.isModalSubmit()) {

        const messageId = interaction.fields.getTextInputValue("messageId");

        const title = interaction.fields.getTextInputValue("editEmbedTitle");

        const description =

          interaction.fields.getTextInputValue("editEmbedDescription");

        const image = interaction.fields.getTextInputValue("editEmbedImage") || null;

        const color = interaction.fields.getTextInputValue("editEmbedColor") || "#00dfff";

        const channel = message.channel;

        const targetMessage = await channel.messages.fetch(messageId).catch(() => null);

        if (!targetMessage) {

          return interaction.reply({

            content: "🚫 **ID الرسالة غير صحيح أو الرسالة غير موجودة.**",

            ephemeral: true,

          });

        }

        const updatedEmbed = new EmbedBuilder()

          .setTitle(title)

          .setDescription(description)

          .setColor(color);

        if (image) updatedEmbed.setImage(image);

        await targetMessage.edit({ embeds: [updatedEmbed] });

        interaction.reply({

          content: "✅ **تم تعديل الإيمبد.**",

          ephemeral: true,

        });

      }

    });

  },

};