const Discord = require("discord.js")

module.exports = {
  name: `send-message`,
  run: async (client, message, args) => {
    if (!message.member.permissions.has("8")) return;

    let embed = new Discord.EmbedBuilder()
      .setColor("#00dfff")
      .setAuthor({ name: "Character Selection" })
      .setImage("https://i.postimg.cc/KYdSvdKL/image.png")
      .setDescription(`**<a:ONLINE:1289715936886132831> - Choose Character\n<:tl:1262585314787201034> - Create Character**`);

    let row = new Discord.ActionRowBuilder().addComponents(
      new Discord.StringSelectMenuBuilder()
        .setCustomId("choose_character")
        .setMaxValues(1)
        .setPlaceholder("اختر شخصية")
        .addOptions([
          { label: "الشخصية الاولى", value: "c1", emoji: "<:Active_MN:1289287993181474817>" },
          { label: "الشخصية الثانية", value: "c2", emoji: "<:Active_MN:1289287993181474817>" }
        ])
    )

    message.delete();
    await message.channel.send({
      embeds: [embed],
      components: [row]
    })

  }
};