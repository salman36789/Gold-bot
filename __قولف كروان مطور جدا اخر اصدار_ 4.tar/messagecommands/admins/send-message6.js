const Discord = require("discord.js")
const { prices } = require("../../config.json")

module.exports = {
    name: `send-message6`,
    run: async (client, message, args) => {
        if (!message.member.permissions.has("8")) return;

        let embed = new Discord.EmbedBuilder()
            .setColor("#00dfff")
            .setImage("https://i.postimg.cc/0NYS73DR/IMG-2222.jpg")
            .setDescription(`**<:1OL_1warrn:1252516293379231764> - For start your manufacturing journey choose the department you want 
And read the Rules here <#1272656958947721309>**`);

        let row = new Discord.ActionRowBuilder().addComponents(
            new Discord.StringSelectMenuBuilder()
                .setCustomId("mach_menu")
                .setMaxValues(1)
                .setPlaceholder("Choose a product")
                .addOptions([
                    { label: "Collecting", value: "collecting", emoji: "<:1OL_1ruless:1252516289457553456>", description: `لبدء التجميع` },
                    { label: "Manufacturing", value: "manufacturing", emoji: "<:tl:1262585306402521159>", description: `لبدء التصنيع` },
                ])
        )

        message.delete();
        await message.channel.send({
            embeds: [embed],
            components: [row]
        })

    }
};