const Discord = require("discord.js")

module.exports = {
  name: `send-message3`,
  run: async (client, message, args) => {
    if (!message.member.permissions.has("8")) return;

    let embed = new Discord.EmbedBuilder()
      .setColor("#00dfff")
      .setImage("https://i.postimg.cc/jSsYsncH/Whats-App-Image-2025-01-14-at-7-41-43-PM.jpg")
      .setDescription(`** <:emoji_121:1252954003013242921> — Town Law System 

<:1OL_1rulesx3:1288375905114128384> — في حال تريد فتح تذكرة في احد التذاكر يجب الضغط على احد انواع التذكرات التي ب الاسفل 

Town Law Management | <:emoji_122:1252954025259831367> **`);

    let row = new Discord.ActionRowBuilder().addComponents(
      new Discord.StringSelectMenuBuilder()
        .setCustomId("ticket_select")
        .setMaxValues(1)
        .setPlaceholder("اختر نوع التكت")
        .addOptions([
          { label: "Support Ticket .", value: "support", emoji: "<:1OL_manege:1275534310421565522>" },
          { label: "Complaint Ticket .", value: "comp", emoji: "<:1OL_1warrn:1252516293379231764>" },
          { label: "High Management Ticket .", value: "high", emoji: "<:1OL_manege:1275534310421565522>" },
          { label: "Add item Ticket .", value: "add", emoji: "<:coins:1328359259414597693>" },
          { label: "Store Ticket .", value: "store", emoji: "<:tl:1262585314787201034>" }
        ])
    )

    message.delete();
    await message.channel.send({
      embeds: [embed],
      components: [row]
    })

  }
};