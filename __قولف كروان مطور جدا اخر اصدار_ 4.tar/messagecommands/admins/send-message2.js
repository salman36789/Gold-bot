const Discord = require("discord.js")

module.exports = {
  name: `send-message2`,
  run: async (client, message, args) => {
    if (!message.member.permissions.has("8")) return;

    let embed = new Discord.EmbedBuilder()
      .setColor("#00dfff")
      .setAuthor({ name: "Game Selection" })
      .setImage("https://i.postimg.cc/jSsYsncH/Whats-App-Image-2025-01-14-at-7-41-43-PM.jpg")
      .setDescription(`**- Choose You Want**`);

    let row = new Discord.ActionRowBuilder().addComponents(
      new Discord.ButtonBuilder()
      .setCustomId("game_start")
      .setLabel("بدأ رحلة")
      .setStyle("Success"),

      new Discord.ButtonBuilder()
      .setCustomId("game_end")
      .setLabel("إعصار")
      .setStyle("Danger"),

      new Discord.ButtonBuilder()
      .setCustomId("game_renew")
      .setLabel("تجديد")
      .setStyle("Secondary"),

      new Discord.ButtonBuilder()
      .setCustomId("game_alert")
      .setLabel("تنبيه")
      .setStyle("Secondary")
    )

    message.delete();
    await message.channel.send({
      embeds: [embed],
      components: [row]
    })

  }
};