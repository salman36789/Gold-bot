const userBase = require('../../Models/userBase')

    , guildBase = require('../../Models/guildBase')

    , Discord = require('discord.js')

module.exports = {

    name: `تفتيش`,

    run: async (client, message, args) => {

        let db = await guildBase.findOne({ guild: message.guild.id })

        if (!db) {

            db = new guildBase({ guild: message.guild.id })

            await db.save();

        }

        let check = db.joins.find(c => c.user === message.author.id)

        if (!check) return message.reply({

            content: `:x: | يجب تسجيل دخولك أولاً حتى تتمكن من استخدام هذا الأمر`

        })

        let data = await userBase.findOne({ guild: message.guild.id, user: message.author.id })

        if (!data) {

            data = new userBase({ guild: message.guild.id, user: message.author.id })

            await data.save();

        }

        data = data[check.character]

        if (data.clamped) return message.reply({

            content: `**<:1OL_1warrn:1252516293379231764> - أنت مكلبش، لا يمكنك استخدام هذا الأمر**`

        })

        let user = message.mentions.users.first()

        if (!user) return message.reply({

            content: `:x: | يجب عليك ذكر الشخص الذي تريد كشف حقيبته`

        })

        let check2 = db.joins.find(c => c.user === user.id)

        if (!check2) return message.reply({

            content: `:x: | لا يمكنك كشف حقيبة ${user} لأنه غير مسجل دخول`

        })

        let userData = await userBase.findOne({ guild: message.guild.id, user: user.id })

        if (!userData) return message.reply({

            content: `:x: | ${user} لا يملك أي أغراض داخل الحقيبة`

        })

        userData = userData[check2.character]

        const allinvs = [], max = 5, inv = [...userData.inv.sort((a, b) => b.count - a.count)];

        if (inv.length <= 0) return message.reply({

            content: `:x: | ${user} لا يملك أي أغراض داخل الحقيبة`

        })

        while (inv.length) {

            allinvs.push(inv.splice(0, max));

        }

        function generateEmbed(page) {

            const embed = new Discord.EmbedBuilder()

                .setColor("#00dfff")

                .setThumbnail(message.guild.iconURL({ dynamic: true }))

                .setDescription(`**<:employeemanalt:1328359209070493837> - Name | ${userData.id.first}

${allinvs[page].map((value, i) => `${i + 1} | ${value.name}\n- Amount | ${value.count}`).join("\n\n")}**`)

            return embed;

        }

        var currentPage = 0;

        let row = new Discord.ActionRowBuilder().addComponents(

            new Discord.ButtonBuilder()

                .setCustomId("back")

                .setStyle("Secondary")

                .setEmoji("<a:OL_BLeft1:1288390502986813511>")

                .setDisabled(currentPage == 0),

            new Discord.ButtonBuilder()

                .setCustomId("next")

                .setStyle("Secondary")

                .setDisabled(userData.inv.length <= max)

                .setEmoji("<a:OL_Aright:1288390501048909834>")

        )

        let msg2 = await message.reply({

            content: `:white_check_mark: | تم كشف حقيبة ${user}`,

            embeds: [generateEmbed(currentPage)],

            components: [row]

        })

        setTimeout(async function(){

            msg2.delete();

            await message.delete();

        }, 100000)

        const collector2 = msg2.createMessageComponentCollector({ componentType: Discord.ComponentType.Button, time: 1200000 });

        collector2.on('collect', async (i2) => {

            if (i2.user.id != message.author.id) return;

            await i2.deferUpdate();

            if (i2.customId === 'back') {

                currentPage -= 1;

                if (currentPage < 0) currentPage = allinvs.length - 1;

            } else if (i2.customId === 'next') {

                currentPage += 1;

                if (currentPage === allinvs.length) currentPage = 0;

            }

            await row.components[0].setDisabled(currentPage === 0);

            await row.components[1].setDisabled(currentPage === allinvs.length - 1);

            await msg2.edit({

                embeds: [generateEmbed(currentPage)],

                components: [row]

            });

        });

    }

};