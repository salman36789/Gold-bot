const Discord = require('discord.js')

    , guildBase = require('../../Models/guildBase')

    , userBase = require('../../Models/userBase')

module.exports = {

    name: `تبصيم`,

    run: async (client, message, args, Discord) => {

        // التحقق من وجود رتبة خاصة

        const requiredRole = "1328570446588674081"; // استبدل هذا باسم الرتبة الخاصة

        if (!message.member.roles.cache.has(requiredRole)) {

            return message.reply({

                content: `:x: | ليس لديك الصلاحية لاستخدام هذا الأمر`

            });

        }

        let user = message.mentions.users.first()

        if (!user) return message.reply({

            content: `:x: | يجب عليك ذكر الشخص الذي تريد تبصيم هويته`

        })

        let character = args[1]

        if (!character || (character !== "1" && character !== "2")) return message.reply({

            content: `:x: | يجب عليك تحديد الشخصية (1 أو 2)`

        })

        character = character === "1" ? "c1" : "c2"

        let db = await userBase.findOne({ guild: message.guild.id, user: user.id })

        if (!db) {

            return message.reply({

                content: `:x: | ${user} ليس لديه هوية`

            });

        }

        db = db[character]

        if (!db.id || Object.keys(db.id).length <= 0) {

            return message.reply({

                content: `:x: | ${user} ليس لديه هوية للشخصية ${character === "c1" ? "1" : "2"}`

            });

        }

        let embed = new Discord.EmbedBuilder()

            .setColor("#00dfff")

            .setDescription(`**<:1OL_1ruless:1252516289457553456> - First Name | ${db.id.first}

<:1OL_1ruless:1252516289457553456> - Last Name | ${db.id.last}

<:1OL_1ruless:1252516289457553456> - Birthday | ${db.id.date}

<:1OL_1ruless:1252516289457553456> - Birth Place | ${db.id.place}

<:1OL_1ruless:1252516289457553456> - Gender | ${db.id.gender}**`)

            .setThumbnail(message.guild.iconURL())

            .setTimestamp();

        message.reply({

            embeds: [embed]

        });

    }

};