const Discord = require('discord.js'),
    guildBase = require('../../Models/guildBase'),
    userBase = require('../../Models/userBase'),
    { bb, gg, ticketLog } = require("../../config.json"), // تأكد من أن ticketLog معرف هنا
    { addPoint } = require("../../functions.js");

module.exports = {
    name: `مخالفة`,
    run: async (client, message, args) => {
        // التحقق من وجود رتبة خاصة
        const requiredRole = "1328570446588674081"; // استبدل هذا بـ ID الرتبة الخاصة
        if (!message.member.roles.cache.has(requiredRole)) {
            return message.reply({ content: `:x: | ليس لديك الصلاحية لاستخدام هذا الأمر` });
        }

        let db = await guildBase.findOne({ guild: message.guild.id });
        if (!db) {
            db = new guildBase({ guild: message.guild.id });
            await db.save();
        }

        let user = message.mentions.users.first();
        if (!user) return message.reply({ content: `:x: | يجب عليك ذكر الشخص الذي تريد إصدار مخالفة له` });

        let check = db.joins.find(c => c.user === user.id);
        if (!check) return message.reply({ content: `:x: | ${user} غير مسجل دخول` });

        let data = await userBase.findOne({ guild: message.guild.id, user: user.id });
        if (!data) {
            data = new userBase({ guild: message.guild.id, user: user.id });
            await data.save();
        }

        if (!data[check.character]) {
            return message.reply({ content: `:x: | لا يوجد بيانات مسجلة للشخصية الخاصة بـ ${user}` });
        }

        let reason = args.slice(2).join(" ");
        if (!reason) return message.reply({ content: `:x: | يجب عليك تحديد سبب المخالفة` });

        let amount = args[1];
        if (!amount || isNaN(amount) || Number(amount) <= 0) {
            return message.reply({ content: `:x: | يجب عليك تحديد مبلغ المخالفة بشكل صحيح` });
        }

        amount = Number(amount);
        let currentCash = data[check.character].cash || 0;

        // خصم المبلغ والتأكد من عدم جعله أقل من الصفر
        data[check.character].cash = Math.max(currentCash - amount, 0 - Math.abs(currentCash));

        await userBase.updateOne(
            { guild: message.guild.id, user: user.id },
            { $set: { [`${check.character}.cash`]: data[check.character].cash } }
        );

        message.reply({
            content: `<:tl:1262585330813636618> | تم إصدار مخالفة لـ ${user} بقيمة ${amount} بسبب: ${reason}`
        });

        let log = message.guild.channels.cache.get(ticketLog);
        if (!log) return;

        log.send({
            embeds: [
                new Discord.EmbedBuilder()
                    .setColor("#00dfff")
                    .setDescription(`**<:1OL_1ruless:1252516289457553456> الشخصية | ${check.character === "c1" ? "1" : "2"}

<:1OL_1ruless:1252516289457553456> - العضو | ${user}

<:1OL_1ruless:1252516289457553456> - المخالفة | ${reason}

<:1OL_1ruless:1252516289457553456> - المبلغ | ${amount}

<:1OL_1ruless:1252516289457553456> - تمت المخالفة بواسطة | ${message.author}

Town Law System .**`)
            ]
        });
    }
};