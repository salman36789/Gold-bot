const userBase = require('../../Models/userBase')

  , guildBase = require('../../Models/guildBase')

  , { invLog } = require('../../config.json')

module.exports = {

  name: `مصادرة`,

  run: async (client, message, args, Discord) => {

    // التحقق من وجود رتبة خاصة

    const requiredRole = "1328570446588674081"; // استبدل هذا باسم الرتبة الخاصة

    if (!message.member.roles.cache.has(requiredRole)) {

      return message.reply({

        content: `:x: | ليس لديك الصلاحية لاستخدام هذا الأمر`

      });

    }

    let db = await guildBase.findOne({ guild: message.guild.id })

    if (!db) {

      db = new guildBase({ guild: message.guild.id })

      await db.save();

    }

    let user = message.mentions.users.first()

    if (!user) return message.reply({

      content: `:x: | يجب عليك ذكر الشخص الذي تريد مصادرة أغراضه`

    })

    let check = db.joins.find(c => c.user === user.id)

    if (!check) return message.reply({

      content: `:x: | ${user} غير مسجل دخول`

    })

    let data = await userBase.findOne({ guild: message.guild.id, user: user.id })

    if (!data) {

      data = new userBase({ guild: message.guild.id, user: user.id })

      await data.save();

    }

    data = data[check.character]

    let amount = args[1]

    if (!amount || isNaN(amount)) return message.reply({

      content: `:x: | يجب عليك تحديد كمية الغرض الذي تريد مصادرته`

    })

    let type = args.slice(2).join(" ")

    if (!type) return message.reply({

      content: `:x: | يجب عليك تحديد الغرض الذي تريد مصادرته`

    })

    let index = data.inv.findIndex(c => c.name.toLowerCase() === type.toLowerCase())

    if (index == -1) return message.reply({

      content: `:x: | ${user} لا يملك غرضًا بهذا الاسم`

    })

    if (data.inv[index].count < Number(amount)) return message.reply({

      content: `:x: | كمية الغرض الذي يملكه ${user} أقل من الكمية التي تريد مصادرتها`

    })

    data.inv[index].count === Number(amount) ? data.inv.splice(index, 1) : data.inv[index].count = parseInt(data.inv[index].count - Number(amount))

    await userBase.updateOne({ guild: message.guild.id, user: user.id },

      {

        $set: {

          [`${check.character}.inv`]: data.inv

        }

      }

    );

    message.reply({

      content: `<:tl:1262585330813636618> | تمت مصادرة ${amount} من ${type} من ${user} بنجاح`

    })

    let log = message.guild.channels.cache.get(invLog)

    if (!log) return;

    log.send({

      embeds: [new Discord.EmbedBuilder().setColor("#00dfff").setDescription(`**<:group2:1328358692676046879> الشخصية | ${check.character === "c1" ? "1" : "2"}

<:employeemanalt:1328359209070493837> - العضو | ${user}

<:emoji_286:1333040124908273686> - المصادرة | ${type} (${amount})

<:1OL_1repost:1329262249415676025> - تمت المصادرة بواسطة | ${message.author}

Town Law System .**`)]

    })

  }

};