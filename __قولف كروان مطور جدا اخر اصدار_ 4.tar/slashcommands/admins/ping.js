const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('يعرض لك تأخير البوت وزمن استجابة API')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator), // السماح فقط للإداريين بتنفيذ الأمر (اختياري)

  async execute(interaction) {
    const sent = await interaction.reply({ content: 'جارٍ القياس...', fetchReply: true });
    const timeTaken = sent.createdTimestamp - interaction.createdTimestamp;
    const apiPing = Math.round(interaction.client.ws.ping);

    await interaction.editReply(`\`\`\`javascript\nوقت الاستجابة: ${timeTaken} ms.\nتأخير API: ${apiPing} ms.\`\`\``);
  },
};