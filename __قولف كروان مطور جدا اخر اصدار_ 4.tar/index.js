require("events").setMaxListeners(10000);

const Database = require('mongoose')
Database.set('strictQuery', true)

const Discord = require("discord.js");
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const client = new Discord.Client({
    intents: [
        Discord.GatewayIntentBits.MessageContent,
        Discord.GatewayIntentBits.Guilds,
        Discord.GatewayIntentBits.GuildMembers,
        Discord.GatewayIntentBits.GuildMessages,
        Discord.GatewayIntentBits.DirectMessages
    ],
    partials: [
        Discord.Partials.GuildScheduledEvent,
        Discord.Partials.Reaction,
        Discord.Partials.Message,
        Discord.Partials.User,
        Discord.Partials.Channel,
        Discord.Partials.GuildMember
    ]
})

client.login("MTI4OTI1MDg4MDY4NzgzNzI2NA.GCHCMU.3tCHmngM2Eap15Jc5Qzso4SqrNhvxuJABeXPYM")

Database.connect("mongodb+srv://haider4441ha:6uNH7xAWxazesbOL@cluster0.wsutq32.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
    .then(() => console.log('Database Connected'))
    .catch((err) => console.log(err))

client.messageCommands = new Discord.Collection()
client.slashCommands = new Discord.Collection()

let handler = ["events", "slash", "message"]
handler.forEach(file => {
    require(`./handler/${file}`)(client);
})

process.on('uncaughtException', (error) => {
    console.error('Uncaught Exception:', error);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

/*client.on(`ready`, () => {
  //client.user.setActivity("Bad Boys RP || غبنا وغاب الابداع ، رجعنا نعدل الاوضاع", { type: 'PLAYING' })
          client.user.setActivity('TLRP ON TOP', {
      type: 'STREAMING',
      url: 'https://twitch.tv/haider' 
      })
    });*/
    
  //join voice
  
  const { joinVoiceChannel } = require('@discordjs/voice');
    
      setInterval( async () => {
      client.channels.fetch("1328570992267755531") //ايدي الروم 
       .then((channel) => { 
        const VoiceConnection = joinVoiceChannel({
         channelId: channel.id, 
         guildId: channel.guild.id, 
         adapterCreator: channel.guild.voiceAdapterCreator 
         });
      }).catch((error) => { return; });
      }, 1000)
  
  setTimeout(() => {
    if (!client || !client.user) {
      console.log("Client Not Login, Process Kill")
      process.kill(1);
    } else {
      console.log("Client Login")
    }
  }, 3 * 1000 * 60);

  // **إرسال الأذكار بشكل دوري**
setInterval(() => {
    let azkarChannel = client.channels.cache.get("1346904270330531922");
    if (!azkarChannel) return console.log('Azkar channel not found.');

    const facts = [
        'اللهم اجعلنا من أهل الذكر والشكر.', 'اللهم ارزقنا علمًا نافعا وعملا صالحًا.',
        'اللهم ثبتنا على الإيمان.', 'اللهم اجعلنا من أهل الجنة.', 'اللهم اغفر لي ولأهلي ولأصدقائي.',
        'اللهم اجعلنا من الذاكرين الله كثيرًا.', 'اللهم اجعلنا من أهل الصلاة.', 'اللهم اجعلنا من أهل القرآن.',
        'اللهم اجعلنا من الذين يحسنون أعمالهم.', 'اللهم اجعلنا من الذين يسيرون على صراطك المستقيم.',
        'اللهم اجعلنا من الذين يحبونك.', 'اللهم اجعلنا من الذين يتبعون سنة نبيك.', 'اللهم اجعلنا من الذين يكثرون من الدعاء.'
    ];

    const fact = facts[Math.floor(Math.random() * facts.length)];
    const embed = new EmbedBuilder()
        .setColor('DarkGrey')
        .setTitle("> 📿〡Athker")
        .setDescription(`**\`\`\`ini\n [ ${fact} ]\n\`\`\`**`)
        .setFooter({ text: "﴿ وَٱذْكُرْ رَبَّكَ إِذَا نَسِيتَ ﴾" });

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('سُبحان الله وبحمده سُبحان الله العظيم')
                .setLabel('سُبحان الله')
                .setStyle(2)
        );

    azkarChannel.send({ embeds: [embed], components: [row] })
        .then(() => {
            if (mv.line) {
                azkarChannel.send({ files: [mv.line] }).catch(error => console.error('Error sending Azkar line:', error));
            }
        })
        .catch(error => console.error('Error sending Azkar message:', error));
}, 1000000);

// معرف القناة التي سيتم إرسال الرسالة فيها
const CHANNEL_ID = ''; // ضع معرف القناة هنا

// إرسال رسالة دورية كل 5 ساعات
const MESSAGE_CONTENT = `
__** <:emoji_121:1252954003013242921> - Town Law Rp ™ Activate **__

**<:tlCorrect:1350552612960862303> - للتفعيل يُرجى كتابة أيديك، في حال كتابة أي شيء آخر سيتم إسكاتك من قبل الطاقم الإداري**
`;

const sendMessage = async () => {
    try {
const channel = await client.channels.fetch(CHANNEL_ID);
        if (channel && channel.isTextBased()) {
            await channel.send('<@&1328570467820240907>');
            await channel.send({ embeds: [new EmbedBuilder()
        .setDescription(MESSAGE_CONTENT)
        .setTitle("Town Law Rp RP ™ .")
        .setColor('#00dfff')
                ]
            });
            console.log('✅ تم إرسال الرسالة بنجاح');
        }
    } catch (error) {
        console.error('❌ حدث خطأ أثناء إرسال الرسالة:', error);
    }
};

// بدء إرسال الرسالة كل ساعتين
setInterval(sendMessage, 7200000);