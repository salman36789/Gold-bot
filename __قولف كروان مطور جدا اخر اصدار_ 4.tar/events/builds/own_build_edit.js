const Discord = require('discord.js'),
    guildBase = require('../../Models/guildBase'),
    userBase = require('../../Models/userBase'),
    { builds } = require('../../builds.json');

module.exports = {
    name: `interactionCreate`,
    run: async (interaction, client) => {
        if (!interaction.isStringSelectMenu()) return;

        if (interaction.customId.startsWith("own_builds_menu")) {
            if (interaction.user.id != interaction.customId.split("_")[3]) return;

            const value = interaction.values[0];

            let db = await guildBase.findOne({ guild: interaction.guild.id });
            if (!db) {
                db = new guildBase({ guild: interaction.guild.id });
                await db.save();
            }

            let check = db.joins.find(c => c.user === interaction.user.id);
            if (!check) return interaction.reply({
                content: `:x: | يجب تسجيل دخولك أولا حتى تتمكن من استخدام المتجر`,
                ephemeral: true
            });

            let data = await userBase.findOne({ guild: interaction.guild.id, user: interaction.user.id });
            if (!data) {
                data = new userBase({ guild: interaction.guild.id, user: interaction.user.id });
                await data.save();
            }

            data = data[check.character];
            if (data.clamped) return interaction.reply({
                ephemeral: true,
                content: `**<:OL_cFalse2:1288390462788603937> - انت مكلبش لا يمكنك التعديل على العقار**`
            });

            let row = new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId(`houseActions_cars_${value}_${interaction.user.id}`)
                    .setStyle("Secondary")
                    .setLabel("House Garage"),

                new Discord.ButtonBuilder()
                    .setCustomId(`houseActions_add_${value}_${interaction.user.id}`)
                    .setStyle("Secondary")
                    .setLabel("Add Safe"),

                new Discord.ButtonBuilder()
                    .setCustomId(`houseActions_take_${value}_${interaction.user.id}`)
                    .setStyle("Secondary")
                    .setLabel("Take Safe"),

                new Discord.ButtonBuilder()
                    .setCustomId(`houseActions_viewSafe_${value}_${interaction.user.id}`)
                    .setStyle("Secondary")
                    .setLabel("View Safe") // ✅ زر لرؤية محتويات الخزنة
            );

            const build = data.builds[value];

            let embed = new Discord.EmbedBuilder()
                .setColor("#00dfff")
                .setImage(`${build.image}`)
                .setDescription(`**<:LOOCC:1288390495030218754> — Apartment Name ( ${build.name} )
🚗 - Garage ( ${build.garage} )
📦 - Storage space ( ${build.storage} )
<:LOOCC1:1288390496905072673> - Apartment Location ( ${build.location} )
<:emoji_345:1329533433000755241> - Apartment Price ( <:emoji_288:1342693078040838275> ${build.price.toLocaleString("en-US")} ) **`);

            await interaction.update({
                embeds: [embed],
                ephemeral: true,
                components: [row]
            });
        }

        // ✅ كود استجابة عند الضغط على زر "View Safe"
        if (interaction.customId.startsWith("houseActions_viewSafe")) {
            if (interaction.user.id != interaction.customId.split("_")[3]) return;

            const value = interaction.customId.split("_")[2];

            let data = await userBase.findOne({ guild: interaction.guild.id, user: interaction.user.id });
            if (!data) return interaction.reply({
                ephemeral: true,
                content: `**❌ | لم يتم العثور على بياناتك في قاعدة البيانات!**`
            });

            let check = data[Object.keys(data)[0]]; // استخراج بيانات الشخصية

            const build = check.builds[value];
            if (!build) return interaction.reply({
                ephemeral: true,
                content: `❌ | لا يوجد منزل بهذه المعلومات!`
            });

            let safeContents = build.safe || "🔒 | الخزنة فارغة.";

            let embed = new Discord.EmbedBuilder()
                .setColor("#FFD700")
                .setTitle(`🔐 خزنة المنزل - ${build.name}`)
                .setDescription(`**${safeContents}**`)
                .setFooter({ text: `Requested by ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() });

            await interaction.reply({ embeds: [embed], ephemeral: true });
        }
    }
};