const Discord = require('discord.js')
    , guildBase = require('../../Models/guildBase')
    , { ticketLog } = require("../../config.json")

module.exports = {
    name: `interactionCreate`,
    run: async (interaction, client) => {
        if (!interaction.isButton()) return;

        if (interaction.customId.startsWith("close")) {
            let topic = interaction.channel.topic.split("|")

            let db = await guildBase.findOne({ guild: interaction.guild.id })
            if (!db) {
                db = new guildBase({ guild: interaction.guild.id })
                await db.save();
            }

            if (!interaction.member.permissions.has("8")
                && interaction.user.id != topic[0].trim()
                && db.claimed.find(c => c.id === interaction.channel.id)?.user != interaction.user.id
            ) return interaction.reply({
                content: `:x: | ليس لديك صلاحيات لقفل هذه التذكرة`,
                ephemeral: true
            })

            let embed = new Discord.EmbedBuilder()
                .setColor("#00dfff")
                .setDescription(`**<:1OL_1warrn:1252516293379231764> - سيتم قفل التذكرة بعد ( 5 ثواني ) **`)

            interaction.reply({
                embeds: [embed]
            }).then(async () => {
                let index = db.claimed.findIndex(c => c.id === interaction.channel.id)
                const claimedOwner = index === -1 ? "لا يوجد" : db.claimed[index].user

                if (index != -1) {
                    db.claimed.splice(index, 1)
                    await db.save();
                }

                setTimeout(async () => {
                    interaction.channel.delete();

                    let ch = interaction.guild.channels.cache.get(ticketLog)
                    if (!ch) reurn;

                    ch.send({
                        embeds: [new Discord.EmbedBuilder().setColor("#00dfff").setDescription(`**<:1OL_1ruless:1252516289457553456> - سجل التذاكر

<:group2:1328358692676046879> - العضو | <@${topic[0].trim()}>

<:tl:1262585314787201034> - الأداري المستلم | ${claimedOwner === "لا يوجد" ? "لا يوجد" : `<@${claimedOwner}>`}

<:tl:1262585330813636618> - تم اقفال التذكرة من قبل | ${interaction.user}

<:1OL_1rules:1252221662129160224> - اسم التذكرة | ${interaction.channel.name}

<:emoji_121:1252954003013242921> - TOWN LAW System .**`)]
                    })
                }, 5000)
            })
        }
    }
};