const Discord = require('discord.js')
    , guildBase = require('../../Models/guildBase')
    , userBase = require('../../Models/userBase')
    , weapon_levels = require("../../weapons.json");

const orders = {
    "1": [
        { name: "Aluminium", count: 150 },
        { name: "Iron", count: 110 },
        { name: "Gunpowder", count: 90 },
        { name: "Plastic", count: 100 },
    ],

    "2": [
        { name: "Aluminium", count: 210 },
        { name: "Iron", count: 98 },
        { name: "Gunpowder", count: 76 },
        { name: "Plastic", count: 111 },
    ],

    "3": [
        { name: "Aluminium", count: 370 },
        { name: "Iron", count: 211 },
        { name: "Gunpowder", count: 140 },
        { name: "Plastic", count: 120 },
    ],

    "4": [
        { name: "Aluminium", count: 390 },
        { name: "Iron", count: 279 },
        { name: "Gunpowder", count: 160 },
        { name: "Plastic", count: 140 },
    ],

    "5": [
        { name: "Aluminium", count: 510 },
        { name: "Iron", count: 310 },
        { name: "Gunpowder", count: 175 },
        { name: "Plastic", count: 160 },
    ],
}

const emojis = {
    "Aluminium": "<:8_1metalz:1240378007777054831>",
    "Gunpowder": "<:8Barod:1240757786585862287>",
    "Plastic": "<:8Blastic:1240756067974254632>",
    "Iron": "<:8_1metalx:1240378218448420884>"
}
module.exports = {
    name: `interactionCreate`,
    run: async (interaction, client) => {
        if (!interaction.isStringSelectMenu()) return;

        if (interaction.customId.startsWith("mach_menu")) {
            let value = interaction.values[0]

            let db = await guildBase.findOne({ guild: interaction.guild.id })
            if (!db) {
                db = new guildBase({ guild: interaction.guild.id })
                await db.save();
            }

            let check = db.joins.find(c => c.user === interaction.user.id)
            if (!check) return interaction.reply({
                content: `:x: | يجب تسجيل دخولك اولا حتى تتمكن من استخدام التجميع`,
                ephemeral: true
            })

            let ban_check = await userBase.findOne({ guild: interaction.guild.id, user: interaction.user.id })
            if (!ban_check) {
                ban_check = new userBase({ guild: interaction.guild.id, user: interaction.user.id })
                await ban_check.save();
            }

            ban_check = ban_check[check.character]
            if (ban_check.clamped) return interaction.reply({
                ephemeral: true,
                content: `**<:wrn:1272223053216219268> - انت مكلبش لايمكنك التجميع**`
            })

            if (value === "collecting") {
                let row = new Discord.ActionRowBuilder().addComponents(
                    new Discord.StringSelectMenuBuilder()
                        .setCustomId(`ores_menu`)
                        .setMaxValues(1)
                        .setPlaceholder("Choose an ore you want to collect")
                        .addOptions([
                            { label: "Aluminium", value: "Aluminium", emoji: "<:8_1metalz:1240378007777054831>" },
                            { label: "Gunpowder", value: "Gunpowder", emoji: "<:8Barod:1240757786585862287>" },
                            { label: "Plastic", value: "Plastic", emoji: "<:8Blastic:1240756067974254632>" },
                            { label: "Iron", value: "Iron", emoji: "<:8_1metalx:1240378218448420884>" }
                        ])
                )

                let embed = new Discord.EmbedBuilder()
                    .setColor("#00dfff")
                    .setImage("https://media.discordapp.net/attachments/1177709566855741470/1307448635461734531/96ce952e90deabd40cd61438a013d604a417df2d.jpg?ex=67b6edad&is=67b59c2d&hm=410c2e6153e686cafbaf3ad2708fc18ec0c7e26e976163fad6346d986e6b543a&")
                    .setDescription(`**<:wrn:1272223053216219268> - Choose the desired type .**`)

                interaction.message.edit({ components: interaction.message.components })
                await interaction.reply({
                    embeds: [embed],
                    ephemeral: true,
                    components: [row]
                })
            } else if (value === "upgrade") {
                if (!db.levels) return interaction.update({
                    content: `:x: | تعذر عملية التطوير بسبب عدم تعيين رتب التطويرات`,
                    embeds: [],
                    components: [],
                    ephemeral: true
                })

                const options = [];
                for (let level = 1; level <= 5; level++) {
                    if (!interaction.member.roles.cache.get(db.levels[level])) {
                        options.push({ label: `Level ${level}`, value: `${level}`, emoji: "<:Level:1283547362681290802>" })
                        break;
                    } else if (level === 5) {
                        return interaction.reply({
                            content: `:x: | وصلت للحد الاقصى من التطويرات.`,
                            ephemeral: true
                        })
                    }
                }

                let row = new Discord.ActionRowBuilder().addComponents(
                    new Discord.StringSelectMenuBuilder()
                        .setCustomId(`levels_menu`)
                        .setMaxValues(1)
                        .setPlaceholder("Choose a level you want to upgrade")
                        .addOptions(options)
                )

                let embed = new Discord.EmbedBuilder()
                    .setColor("#00dfff")
                    .setImage("https://media.discordapp.net/attachments/1177709566855741470/1307448635461734531/96ce952e90deabd40cd61438a013d604a417df2d.jpg?ex=67b6edad&is=67b59c2d&hm=410c2e6153e686cafbaf3ad2708fc18ec0c7e26e976163fad6346d986e6b543a&")
                    .setDescription(`**<:wrn:1272223053216219268> - Choose the level .**`)

                interaction.message.edit({ components: interaction.message.components })
                await interaction.reply({
                    embeds: [embed],
                    ephemeral: true,
                    components: [row]
                })
            } else if (value === "manufacturing") {
                if (!db.levels) return interaction.update({
                    content: `:x: | تعذر عملية التطوير بسبب عدم تعيين رتب التطويرات`,
                    embeds: [],
                    components: [],
                    ephemeral: true
                })

                const userRoles = interaction.member.roles.cache.map(role => role.id);
                const check_roles = Object.values(db.levels).some(roleId => userRoles.includes(roleId));
                if (!check_roles) {
                    interaction.message.edit({ components: interaction.message.components })
                    return interaction.reply({
                        content: ":x: | أنت لا تمتلك أي تطويرات حتى الان",
                        embeds: [],
                        components: [],
                        ephemeral: true
                    });
                }

                const options = [];
                for (let level = 1; level <= 5; level++) {
                    if (interaction.member.roles.cache.get(db.levels[level])) {
                        options.push({ label: `Level ${level}`, value: `${level}`, emoji: "<:Level:1283547362681290802>" })
                    }
                }

                let row = new Discord.ActionRowBuilder().addComponents(
                    new Discord.StringSelectMenuBuilder()
                        .setCustomId(`weaponlevels_menu`)
                        .setMaxValues(1)
                        .setPlaceholder("Choose a level you want to upgrade")
                        .addOptions(options)
                )

                let embed = new Discord.EmbedBuilder()
                    .setColor("#00dfff")
                    .setImage("https://media.discordapp.net/attachments/1177709566855741470/1307448635461734531/96ce952e90deabd40cd61438a013d604a417df2d.jpg?ex=67b6edad&is=67b59c2d&hm=410c2e6153e686cafbaf3ad2708fc18ec0c7e26e976163fad6346d986e6b543a&")
                    .setDescription(`**<:wrn:1272223053216219268> - Choose the level .**`)

                interaction.message.edit({ components: interaction.message.components })
                await interaction.reply({
                    embeds: [embed],
                    ephemeral: true,
                    components: [row]
                })
            }
        }

        if (interaction.customId.startsWith("ores_menu")) {
            let value = interaction.values[0]

            let db = await guildBase.findOne({ guild: interaction.guild.id })
            if (!db) {
                db = new guildBase({ guild: interaction.guild.id })
                await db.save();
            }

            let check = db.joins.find(c => c.user === interaction.user.id)
            if (!check) return interaction.reply({
                content: `:x: | يجب تسجيل دخولك اولا حتى تتمكن من استخدام التجميع`,
                ephemeral: true
            })

            let ban_check = await userBase.findOne({ guild: interaction.guild.id, user: interaction.user.id })
            if (!ban_check) {
                ban_check = new userBase({ guild: interaction.guild.id, user: interaction.user.id })
                await ban_check.save();
            }

            ban_check = ban_check[check.character]
            if (ban_check.clamped) return interaction.reply({
                ephemeral: true,
                content: `**<:wrn:1272223053216219268> - انت مكلبش لايمكنك التجميع**`
            })

            let row = new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId(`acollect_start_${value}`)
                    .setLabel("Start")
                    .setStyle("Success"),

                new Discord.ButtonBuilder()
                    .setCustomId(`acollect_cancel`)
                    .setLabel("Cancel")
                    .setStyle("Danger")
            )

            let embed = new Discord.EmbedBuilder()
                .setColor("#00dfff")
                .setDescription(`**<:1OL_1loading1:1252516287607869490> To start collect __${value}__, click (Start)**`)

            await interaction.update({
                embeds: [embed],
                ephemeral: true,
                components: [row]
            })
        }

        if (interaction.customId.startsWith("weaponlevels_menu")) {
            let value = interaction.values[0]

            let db = await guildBase.findOne({ guild: interaction.guild.id })
            if (!db) {
                db = new guildBase({ guild: interaction.guild.id })
                await db.save();
            }

            let check = db.joins.find(c => c.user === interaction.user.id)
            if (!check) return interaction.reply({
                content: `:x: | يجب تسجيل دخولك اولا حتى تتمكن من استخدام التصنيع`,
                ephemeral: true
            })

            let ban_check = await userBase.findOne({ guild: interaction.guild.id, user: interaction.user.id })
            if (!ban_check) {
                ban_check = new userBase({ guild: interaction.guild.id, user: interaction.user.id })
                await ban_check.save();
            }

            ban_check = ban_check[check.character]
            if (ban_check.clamped) return interaction.reply({
                ephemeral: true,
                content: `**<:wrn:1272223053216219268> - انت مكلبش لايمكنك التصنيع**`
            })

            let row = new Discord.ActionRowBuilder().addComponents(
                new Discord.StringSelectMenuBuilder()
                    .setCustomId(`weapons_${value}`)
                    .setMaxValues(1)
                    .setPlaceholder("Choose a weapon you want to manufacture")
                    .addOptions(weapon_levels[value].map((c, i) => {
                        return { label: `${c.name}`, value: `${i}`, emoji: `${c.emoji}` }
                    }))
            )

            let embed = new Discord.EmbedBuilder()
                .setColor("#00dfff")
                .setDescription(`**<:wrn:1272223053216219268> - Choose the weapon**`)

            await interaction.update({
                embeds: [embed],
                ephemeral: true,
                components: [row]
            })
        }

        if (interaction.customId.startsWith("weapons")) {
            let value = interaction.values[0]
            let index = interaction.customId.split("_")[1]

            const weapon = weapon_levels[index][value]

            let db = await guildBase.findOne({ guild: interaction.guild.id })
            if (!db) {
                db = new guildBase({ guild: interaction.guild.id })
                await db.save();
            }

            let check = db.joins.find(c => c.user === interaction.user.id)
            if (!check) return interaction.reply({
                content: `:x: | يجب تسجيل دخولك اولا حتى تتمكن من استخدام التصنيع`,
                ephemeral: true
            })

            let row = new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId(`manufacture_success_${index}_${value}`)
                    .setLabel("Manufacturing")
                    .setStyle("Success"),

                new Discord.ButtonBuilder()
                    .setCustomId(`manufacture_cancel`)
                    .setLabel("Cancel")
                    .setStyle("Danger")
            )

            let embed = new Discord.EmbedBuilder()
                .setColor("#00dfff")
                .setImage(`${weapon.image}`)
                .setDescription(`**Weapons | ${weapon.name}

 Aluminium
Number | ${weapon.Aluminium}

 Iron
Number | ${weapon.Iron}

 Gunpowder
Number | ${weapon.Gunpowder}

 Plastic
Number | ${weapon.Plastic}**`)

            await interaction.update({
                embeds: [embed],
                ephemeral: true,
                components: [row]
            })
        }

        if (interaction.customId.startsWith("levels_menu")) {
            let value = interaction.values[0]

            let db = await guildBase.findOne({ guild: interaction.guild.id })
            if (!db) {
                db = new guildBase({ guild: interaction.guild.id })
                await db.save();
            }

            let check = db.joins.find(c => c.user === interaction.user.id)
            if (!check) return interaction.reply({
                content: `:x: | يجب تسجيل دخولك اولا حتى تتمكن من استخدام التطوير`,
                ephemeral: true
            })

            let ban_check = await userBase.findOne({ guild: interaction.guild.id, user: interaction.user.id })
            if (!ban_check) {
                ban_check = new userBase({ guild: interaction.guild.id, user: interaction.user.id })
                await ban_check.save();
            }

            ban_check = ban_check[check.character]
            if (ban_check.clamped) return interaction.reply({
                ephemeral: true,
                content: `**<:wrn:1272223053216219268> - انت مكلبش لايمكنك التطوير**`
            })

            let row = new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId(`aupgrade_${value}`)
                    .setLabel("Promotion")
                    .setStyle("Success")
            )

            let embed = new Discord.EmbedBuilder()
                .setColor("#00dfff")
                .setDescription(`**${orders[value].map(item => `${emojis[item.name]} ${item.name} | ${item.count}`).join("\n")}**`)

            await interaction.update({
                embeds: [embed],
                ephemeral: true,
                components: [row]
            })
        }
    }
};
