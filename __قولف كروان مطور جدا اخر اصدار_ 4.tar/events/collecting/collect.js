const Discord = require('discord.js')
    , guildBase = require('../../Models/guildBase')
    , userBase = require('../../Models/userBase')
    , users = new Map();

const emojis = {
    "Aluminium": "<:8_1metalz:1240378007777054831>",
    "Gunpowder": "<:8Barod:1240757786585862287>",
    "Plastic": "<:8Blastic:1240756067974254632>",
    "Iron": "<:8_1metalx:1240378218448420884>"
}

module.exports = {
    users,
    name: `interactionCreate`,
    run: async (interaction, client) => {
        if (!interaction.isButton()) return;

        if (interaction.customId.startsWith("acollect")) {
            let choice = interaction.customId.split("_")[1]

            let db = await guildBase.findOne({ guild: interaction.guild.id })
            if (!db) {
                db = new guildBase({ guild: interaction.guild.id })
                await db.save();
            }

            let check = db.joins.find(c => c.user === interaction.user.id)
            if (!check) return interaction.reply({
                content: `:x: | يجب تسجيل دخولك اولا حتى تتمكن من استخدام التجميع`,
                ephemeral: true
            })

            if (choice === "start") {
                if (users.has(interaction.user.id)) return interaction.update({
                    content: `:x: | لديك عملية تجميع بالفعل`,
                    embeds: [],
                    components: [],
                    ephemeral: true
                })

                users.set(interaction.user.id, true)

                let value = interaction.customId.split("_")[2]

                let embed = new Discord.EmbedBuilder()
                    .setColor("#00dfff")
                    .setDescription(`**<:wrn:1272223053216219268> - Please wait until the download is complete .**`)
                    .setImage("https://media.discordapp.net/attachments/1119979704187899966/1310322016854872064/5dc3ccae47d20dedb229267b811ff239.gif?ex=6748c079&is=67476ef9&hm=1fee0bed369e9bc22cd1322539ae45c84dc1957b904a37e3a972f3a3357fc2b9&")

                interaction.update({
                    embeds: [embed],
                    ephemeral: true,
                    components: []
                }).then(async () => {
                    const random = Math.floor(Math.random() * 12) + 1

                    let data = await userBase.findOne({ guild: interaction.guild.id, user: interaction.user.id })
                    data = data[check.character]

                    let index = data.inv.findIndex(c => c.name.toLowerCase() === value.toLowerCase())
                    index === -1 ? data.inv.push({ name: value, count: random }) : data.inv[index].count += random

                    setTimeout(async function () {
                        await userBase.updateOne({ guild: interaction.guild.id, user: interaction.user.id },
                            {
                                $set: {
                                    [`${check.character}`]: data
                                }
                            }
                        );

                        let row = new Discord.ActionRowBuilder().addComponents(
                            new Discord.ButtonBuilder()
                                .setCustomId(`acollect_start_${value}`)
                                .setLabel("Replay")
                                .setStyle("Success"),

                            new Discord.ButtonBuilder()
                                .setCustomId(`acollect_cancel`)
                                .setLabel("Cancel")
                                .setStyle("Danger")
                        )

                        users.delete(interaction.user.id)

                        interaction.editReply({
                            ephemeral: true,
                            components: [row],
                            embeds: [new Discord.EmbedBuilder().setColor("#00dfff").setDescription(`**<:tl:1262585330813636618> - Assembly completed successfully . 

${emojis[value]} - ${value} | ${random}**`)]
                        })

                        if(!db.make_log) return;
                        let log = interaction.guild.channels.cache.get(db.make_log)
                        if(!log) return;

                        log.send({
                            embeds: [new Discord.EmbedBuilder().setColor("#00dfff").setDescription(`**  Manufacturing Log 

 - الشخص | ${interaction.user}

 - العنصر | ${value}

 - العدد | ${random}

 - الشخصية | ${check.character === "c1" ? "1" : "2"}

\`\`  Town Law System . \`\`**`)]
                        })
                    }, 8000)
                })
            } else if (choice === "cancel") {
                let embed = new Discord.EmbedBuilder()
                    .setColor("#00dfff")
                    .setDescription(`**<:tl:1262585330813636618> - Assembly canceled successfully .**`)

                await interaction.update({
                    embeds: [embed],
                    ephemeral: true,
                    components: []
                })

                users.delete(interaction.user.id)
            }
        }
    }
};