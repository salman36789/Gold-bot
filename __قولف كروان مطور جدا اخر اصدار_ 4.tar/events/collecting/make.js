const Discord = require('discord.js')
    , guildBase = require('../../Models/guildBase')
    , userBase = require('../../Models/userBase')
    , users = new Map()
    , weapons = require("../../weapons.json")

function checkInv(items, inv) {
    return items.every(item => {
        const itemInInv = inv.find(invItem => invItem.name.toLowerCase() === item.name.toLowerCase());
        return itemInInv && itemInInv.count >= item.count;
    });
}

module.exports = {
    users,
    name: `interactionCreate`,
    run: async (interaction, client) => {
        if (!interaction.isButton()) return;

        if (interaction.customId.startsWith("manufacture")) {
            let choice = interaction.customId.split("_")[1]

            let db = await guildBase.findOne({ guild: interaction.guild.id })
            if (!db) {
                db = new guildBase({ guild: interaction.guild.id })
                await db.save();
            }

            let check = db.joins.find(c => c.user === interaction.user.id)
            if (!check) return interaction.reply({
                content: `:x: | يجب تسجيل دخولك اولا حتى تتمكن من استخدام تصنيع`,
                ephemeral: true
            })

            if (choice === "cancel") {
                let embed = new Discord.EmbedBuilder()
                    .setColor("#00dfff")
                    .setDescription(`**<:tl:1262585330813636618> - Manufacturing canceled successfully .**`)

                await interaction.update({
                    embeds: [embed],
                    ephemeral: true,
                    components: []
                })

                users.delete(interaction.user.id)
            } else {
                let index = interaction.customId.split("_")[2]
                    , value = interaction.customId.split("_")[3]

                const weapon = weapons[index][value]
                    , order = [
                        { name: "Aluminium", count: weapon.Aluminium },
                        { name: "Iron", count: weapon.Iron },
                        { name: "Gunpowder", count: weapon.Gunpowder },
                        { name: "Plastic", count: weapon.Plastic }
                    ]

                if (users.has(interaction.user.id)) return interaction.update({
                    content: `:x: | لديك عملية تصنيع بالفعل`,
                    embeds: [],
                    components: [],
                    ephemeral: true
                })

                let data = await userBase.findOne({ guild: interaction.guild.id, user: interaction.user.id })
                data = data[check.character]

                if (!checkInv(order, data.inv)) return interaction.update({
                    content: `:x: | لا تمتلك الاغراض المطلوبة`,
                    embeds: [],
                    components: [],
                    ephemeral: true
                })

                users.set(interaction.user.id, true)

                let embed = new Discord.EmbedBuilder()
                    .setColor("#00dfff")
                    .setDescription(`**<:wrn:1272223053216219268> - Please wait until the download is complete .**`)
                    .setImage("https://media.discordapp.net/attachments/1119979704187899966/1310322016854872064/5dc3ccae47d20dedb229267b811ff239.gif?ex=6748c079&is=67476ef9&hm=1fee0bed369e9bc22cd1322539ae45c84dc1957b904a37e3a972f3a3357fc2b9&")

                interaction.update({
                    embeds: [embed],
                    ephemeral: true,
                    components: []
                }).then(async () => {
                    order.forEach(item => {
                        let ind = data.inv.findIndex(c => c.name.toLowerCase() === item.name.toLowerCase())
                        data.inv[ind].count === item.count ? data.inv.splice(ind, 1) : data.inv[ind].count -= item.count
                    });

                    let ind2 = data.inv.findIndex(c => c.name.toLowerCase() === weapon.name.toLowerCase())
                    ind2 === -1 ? data.inv.push({ name: `${weapon.name}`, count: 1 }) : data.inv[ind2].count += 1

                    setTimeout(async function () {
                        await userBase.updateOne({ guild: interaction.guild.id, user: interaction.user.id },
                            {
                                $set: {
                                    [`${check.character}`]: data
                                }
                            }
                        );

                        users.delete(interaction.user.id)

                        interaction.editReply({
                            content: `**<:tl:1262585330813636618> - You successfully manufacturing ( ${weapon.name} )**`,
                            embeds: [],
                            components: [],
                            ephemeral: true
                        })

                        if(!db.make_log) return;
                        let log = interaction.guild.channels.cache.get(db.make_log)
                        if(!log) return;

                        log.send({
                            embeds: [new Discord.EmbedBuilder().setColor("#00dfff").setDescription(`** Manufacturing Log 

 - الشخص | ${interaction.user}

 - السلاح | ${weapon.name}

 - الشخصية | ${check.character === "c1" ? "1" : "2"}

\`\` Town Law System . \`\`**`)]
                        })
                    }, 9000)
                })
            }
        }
    }
}