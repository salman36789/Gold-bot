const Discord = require('discord.js')
    , guildBase = require('../../Models/guildBase')
    , userBase = require('../../Models/userBase')
    , { addPoint } = require("../../functions");

module.exports = {
    name: `interactionCreate`,
    run: async (interaction, client) => {
        if (!interaction.isButton()) return;

        if (interaction.customId.startsWith("status")) {
            if(!interaction.member.permissions.has("8")) return interaction.reply({
                content: `:x: | ليس لديك صلاحيات لاستخدام هذه الازرار`,
                ephemeral: true
            })
            
            let data = await guildBase.findOne({ guild: interaction.guild.id })
            if(!data) {
                data = new guildBase({ guild: interaction.guild.id })
                await data.save()
            }

            if(!data.status) return interaction.reply({
                content: `:x: | لا أستطيع ايجاد روم حالة السيرفر`,
                ephemeral: true
            })

            let channel = interaction.guild.channels.cache.get(data.status.channel)
            if(!channel) return interaction.reply({
                content: `:x: | لا أستطيع ايجاد روم حالة السيرفر`,
                ephemeral: true
            })

            const fetchedMessage = await channel.messages.fetch(data.status.message);
            if(!fetchedMessage) return interaction.reply({
                content: `:x: | لا أستطيع ايجاد رسالة الحالة`
            })

            let choice = interaction.customId.split("_")[1]
            , emoji = choice === "online" ? "<:Online:1250965894205669406>" : choice === "offline" ? "<:Obusy:1250965898697642016>" : "<:Restart:1250965892901371946>"

            fetchedMessage.embeds[0].data.description = `**Server Status | ${choice.charAt(0).toUpperCase() + choice.slice(1)} ${emoji}**`

            await fetchedMessage.edit({ embeds: fetchedMessage.embeds })

            await interaction.reply({
                content: `:white_check_mark: | تم تغير حالة السيرفر`,
                ephemeral: true
            })
        }
    }
};