const Discord = require('discord.js')
    , guildBase = require('../../Models/guildBase')
    , { cars } = require('../../cars.json')
    , userBase = require('../../Models/userBase')
    , { invLog } = require("../../config.json");

module.exports = {
    name: `interactionCreate`,
    run: async (interaction, client) => {
        if (!interaction.isButton()) return;

        if (interaction.customId.startsWith("bbcar")) {
            const value = interaction.customId.split("_")[1]
                , car = cars[interaction.customId.split("_")[2]]
                , house = interaction.customId.split("_")[3]

            if (value === "confirm") {
                let db = await guildBase.findOne({ guild: interaction.guild.id })
                if (!db) {
                    db = new guildBase({ guild: interaction.guild.id })
                    await db.save();
                }

                let check = db.joins.find(c => c.user === interaction.user.id)
                if (!check) return interaction.reply({
                    content: `:x: | يجب تسجيل دخولك اولا حتى تتمكن من استخدام هذا الزر`,
                    ephemeral: true
                })

                let data = await userBase.findOne({ guild: interaction.guild.id, user: interaction.user.id })
                if (!data) {
                    data = new userBase({ guild: interaction.guild.id, user: interaction.user.id })
                    await data.save();
                }
                data = data[check.character]

                data.cars.push(car)
                data.builds[house].cars.push(car)
                data.cash -= Number(car.price)
                await userBase.updateOne({ guild: interaction.guild.id, user: interaction.user.id },
                    {
                        $set: {
                            [`${check.character}`]: data
                        }
                    }
                );

                await interaction.update({
                    components: [],
                    ephemeral: true,
                    embeds: [new Discord.EmbedBuilder().setColor("#00dfff").setDescription(`**<:tl:1262585330813636618> - Car Successfully Bought**`)]
                })

                let channel = interaction.guild.channels.cache.get(invLog)
                if (!channel) return;

                channel.send({
                    embeds: [new Discord.EmbedBuilder().setColor("#00dfff").setDescription(`**<:tl:1262585314787201034> الشخصية | ${check.character === "c1" ? "الاولى" : "الثانية"}

<:group2:1328358692676046879> - العضو | ${interaction.user}

<:1OL_1warrn:1252516293379231764> - السيارة | ${car.name}

<:coins:1328359259414597693> - بسعر | <:emoji_288:1342693078040838275> ${car.price}

TOWN LAW System .**`)]
                })
            } else {
                interaction.update({
                    components: [],
                    ephemeral: true,
                    embeds: [new Discord.EmbedBuilder().setColor("#00dfff").setDescription(`**<:tl:1262585330813636618> - Car Successfully Canceled**`)]
                })
            }
        }
    }
};
