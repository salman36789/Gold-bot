const Discord = require('discord.js')
    , guildBase = require('../../Models/guildBase')
    , userBase = require('../../Models/userBase')
    , { prices, names } = require('../../config.json')

module.exports = {
    name: `interactionCreate`,
    run: async (interaction, client) => {
        if (!interaction.isStringSelectMenu()) return;

        if (interaction.customId.startsWith("buy_menu")) {
            let values = interaction.values

            let db = await guildBase.findOne({ guild: interaction.guild.id })
            if (!db) {
                db = new guildBase({ guild: interaction.guild.id })
                await db.save();
            }

            let check = db.joins.find(c => c.user === interaction.user.id)
            if (!check) return interaction.reply({
                content: `:x: | يجب تسجيل دخولك اولا حتى تتمكن من استخدام المتجر`,
                ephemeral: true
            })

            let ban_check = await userBase.findOne({ guild: interaction.guild.id, user: interaction.user.id })
            if(!ban_check) {
                ban_check = new userBase({ guild: interaction.guild.id, user: interaction.user.id })
                await ban_check.save();
            }

            ban_check = ban_check[check.character]

            if(ban_check.clamped) return interaction.reply({
                ephemeral: true,
                content: `**<:1OL_1warrn:1252516293379231764> - انت مكلبش لايمكنك استخدام المتجر**`
            })

            var total = 0
            values.forEach(value => total += prices[value])

            let row = new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId(`buy_confirm_${total}_${values.map(c => c).join("**")}`)
                    .setStyle("Success")
                    .setLabel("Buy"),

                new Discord.ButtonBuilder()
                    .setCustomId(`buy_cancel`)
                    .setStyle("Danger")
                    .setLabel("Cancel")
            )

            let embed = new Discord.EmbedBuilder()
                .setColor("#00dfff")
                .setAuthor({ name: "Buy Receipt" })
                .setDescription(`**${values.map(value => `<:1OL_1ruless:1252516289457553456> - Name | ${names[value]}
<:emoji_345:1329533433000755241> - Price | ${prices[value]}`).join("\n\n")}\nــــــــ\nTotal: ${total}**`)

interaction.message.edit({ components: interaction.message.components })
            await interaction.reply({
                embeds: [embed],
                ephemeral: true,
                components: [row]
            })


        }
    }
};