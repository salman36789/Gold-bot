const Discord = require('discord.js')
    , guildBase = require('../../Models/guildBase')
    , userBase = require('../../Models/userBase')
    , { prices, invLog, names } = require("../../config.json")
    , { addPoint } = require("../../functions.js")

module.exports = {
    name: `interactionCreate`,
    run: async (interaction, client) => {
        if (!interaction.isButton()) return;

        if (interaction.customId.startsWith("buy")) {
            let action = interaction.customId.split("_")[1]

            let db = await guildBase.findOne({ guild: interaction.guild.id })
            if (!db) {
                db = new guildBase({ guild: interaction.guild.id })
                await db.save();
            }

            let check = db.joins.find(c => c.user === interaction.user.id)
            if (!check) return interaction.reply({
                content: `:x: | يجب تسجيل دخولك اولا حتى تتمكن من استخدام المتجر`,
                ephemeral: true
            })

            if (action === "cancel") {
                await interaction.update({
                    components: [],
                    embeds: [new Discord.EmbedBuilder().setColor("#00dfff").setDescription(`**<:tl:1262585330813636618> - Your progress has been canceled**`)]
                })
            } else if (action === "confirm") {
                let total = interaction.customId.split("_")[2]
                let values = interaction.customId.split(`buy_confirm_${total}_`)[1].split("**")

                let data = await userBase.findOne({ guild: interaction.guild.id, user: interaction.user.id })
                if (!data) {
                    data = new userBase({ guild: interaction.guild.id, user: interaction.user.id })
                    await data.save();
                }

                data = data[check.character]

                if (data.cash < Number(total)) return interaction.update({
                    components: [],
                    embeds: [],
                    content: `:x: | كاشك أقل من سعر المنتجات`
                })

                data.cash -= Number(total)
                values.forEach(value => {
                    let check = data.inv.find(c => c.name.toLowerCase() === value)
                    if (check) {
                        check.count += 1
                    } else {
                        data.inv.push({ name: names[value], count: 1 })
                    }
                })                

                await userBase.updateOne({ guild: interaction.guild.id, user: interaction.user.id },
                    {
                        $set: {
                            [`${check.character}`]: data
                        }
                    }
                );

                interaction.update({
                    embeds: [new Discord.EmbedBuilder().setColor("#00dfff").setDescription(`**<:tl:1262585330813636618> - Your progress successfully completed**`)],
                    components: []
                })

                let channel = interaction.guild.channels.cache.get(invLog)
                if(!channel) return;

                channel.send({
                    embeds: [new Discord.EmbedBuilder().setColor("#00dfff").setDescription(`**<:tl:1262585314787201034> الشخصية | ${check.character === "c1" ? "الاولى" : "الثانية"}

<:group2:1328358692676046879> - العضو | ${interaction.user}

<:1OL_1warrn:1252516293379231764> - تم شراء | ${values.filter(c => c != "").map(c => names[c]).join(" -")}

<:coins:1328359259414597693> - بسعر | ${total}

TOWN LAW System .**`)]
                })

            }
        }
    }
};