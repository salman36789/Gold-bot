const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const userBase = require('../../Models/userBase');
const { thefts } = require('../../thefts.json');

module.exports = {
    name: 'interactionCreate',
    run: async (interaction, client) => {
        if (!interaction.isStringSelectMenu()) return;

        if (interaction.customId === 'theft_type') {
            const selectedTheft = thefts.find((t) => t.name.toLowerCase() === interaction.values[0]);
            if (!selectedTheft) return;

            const data = await userBase.findOne({ guild: interaction.guild.id, user: interaction.user.id });
            if (!data) return interaction.reply({ content: '⚠️ Your data was not found.', ephemeral: true });
            
            const activeCharacter = data.c1?.id ? data.c1 : data.c2;
            if (!activeCharacter || !activeCharacter.inv) {
                return interaction.reply({ content: '⚠️ No toolbag is linked to your character.', ephemeral: true });
            }

            if (!client.activeThefts) client.activeThefts = new Map();
            if (client.activeThefts.has(interaction.user.id)) {
                return interaction.reply({ content: '⚠️ You have an active theft. Please finish it before starting a new one.', ephemeral: true });
            }

            function hasRequiredItems(wants, inventory) {
                return wants.every((wanted) => {
                    if (!wanted) return false;
                    let count = 1;
                    const match = wanted.match(/(\d+)\s*(.+)/);
                    if (match) {
                        count = parseInt(match[1], 10);
                        wanted = match[2].trim();
                    }
                    const item = inventory.find((i) => {
                        if (!i || !i.name) return false;
                        return i.name.toLowerCase() === wanted.toLowerCase();
                    });
                    return item && item.count >= count;
                });
            }

            if (!hasRequiredItems(selectedTheft.wants, activeCharacter.inv)) {
                return interaction.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setDescription(`**<:wrn:1272223053216219268> - You don’t have the required items for the theft in your bag, which are:**\n\`\`\`${selectedTheft.wants.join('\n')}\`\`\`
`)
                            .setColor('#00dfff'),
                    ],
                    ephemeral: true,
                });
            }

            function removeRequiredItems(wants, inventory) {
                wants.forEach((wanted) => {
                    if (!wanted) return;
                    let count = 1;
                    const match = wanted.match(/(\d+)\s*(.+)/);
                    if (match) {
                        count = parseInt(match[1], 10);
                        wanted = match[2].trim();
                    }
                    const itemIndex = inventory.findIndex((i) => {
                        if (!i || !i.name) return false;
                        return i.name.toLowerCase() === wanted.toLowerCase();
                    });
                    if (itemIndex !== -1) {
                        inventory[itemIndex].count -= count;
                        if (inventory[itemIndex].count <= 0) {
                            inventory.splice(itemIndex, 1);
                        }
                    }
                });
            }

            function addReward(reward, character) {
                if (typeof reward === 'string') {
                    if (reward.toLowerCase().includes('money')) {
                        const amount = parseInt(reward.match(/\d+/)[0]);
                        character.bank = (character.bank || 0) + amount;
                    } else {
                        const match = reward.match(/(\d+)\s*(.+)/);
                        let count = 1;
                        let name = reward.trim();
                        if (match) {
                            count = parseInt(match[1], 10);
                            name = match[2].trim();
                        }
                        const existingItem = character.inv.find((i) => {
                            if (!i || !i.name) return false;
                            return i.name.toLowerCase() === name.toLowerCase();
                        });
                        if (existingItem) {
                            existingItem.count += count;
                        } else {
                            character.inv.push({ name, count });
                        }
                    }
                } else if (typeof reward === 'number') {
                    character.bank = (character.bank || 0) + reward;
                }
            }

            removeRequiredItems(selectedTheft.wants, activeCharacter.inv);
            client.activeThefts.set(interaction.user.id, true);

            const correctCode = generateRandomSymbols(8);
            const fakeCodes = Array.from({ length: 4 }, () => generateRandomSymbols(8));
            const allCodes = shuffleArray([correctCode, ...fakeCodes]);

            await interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setDescription(`**Save these symbols: \`${correctCode}\`
**`)
                        .setColor('#9013fe'),
                ],
                ephemeral: true,
            });

            const reportChannel = client.channels.cache.get('1339238617381474430');
            if (reportChannel) {
                await reportChannel.send({
                    content: '<@&1328570446588674081>',
                    embeds: [
                        new EmbedBuilder()
                            .setTitle('** Theft Report <:1OL_1warn:1288375939415412738> **')
                            .setDescription(`**
- Member: <@${interaction.user.id}>\n- Theft: ${selectedTheft.name} **`)
                            .setColor('#ff0000'),
                    ],
                });
            }

            setTimeout(async () => {
                const buttons = new ActionRowBuilder().addComponents(
                    allCodes.map((code) =>
                        new ButtonBuilder()
                            .setLabel(code)
                            .setCustomId(code === correctCode ? 'correct_code' : `wrong_code_${code}`)
                            .setStyle(ButtonStyle.Primary)
                    )
                );

                await interaction.editReply({
                    embeds: [
                        new EmbedBuilder()
                            .setDescription(`**Choose the correct symbol from the buttons below:
-# اختر الرمز الصحيح من الأزرار أدناه
**`)
                            .setColor('#00dfff'),
                    ],
                    components: [buttons],
                });

                const buttonFilter = (btnInteraction) =>
                    btnInteraction.user.id === interaction.user.id &&
                    (btnInteraction.customId === 'correct_code' || btnInteraction.customId.startsWith('wrong_code_'));

                const buttonCollector = interaction.channel.createMessageComponentCollector({
                    filter: buttonFilter,
                    max: 1,
                    time: 5000,
                });

                buttonCollector.on('collect', async (btnInteraction) => {
                    if (btnInteraction.customId === 'correct_code') {
                        const randomReward = selectedTheft.add[Math.floor(Math.random() * selectedTheft.add.length)];

                        let progress = 0;
                        const progressButton = new ButtonBuilder()
                            .setCustomId('progress_button')
                            .setLabel(`Progress: ${progress}%`)
                            .setStyle(ButtonStyle.Secondary)
                            .setDisabled(true);

                        const progressRow = new ActionRowBuilder().addComponents(progressButton);

                        await btnInteraction.reply({
                            content: `**Executing the theft...
-# تنفيذ السرقة... 
**`,
                            components: [progressRow],
                            ephemeral: true,
                        });

                        const progressInterval = setInterval(async () => {
                            progress += 1;
                            progressButton.setLabel(`Progress: ${progress}%`);

                            await btnInteraction.editReply({
                                content: `**Executing the theft...
-# تنفيذ السرقة... 
**`,
                                components: [progressRow],
                            });

                            if (progress >= 300) {
                                clearInterval(progressInterval);
                                try {
                                    addReward(randomReward, activeCharacter);
                                    await data.save();

                                    await btnInteraction.editReply({
                                        embeds: [
                                            new EmbedBuilder()
                                                .setDescription(
                                                    `**Theft was successful! You received:\n\`\`\`${randomReward}\`\`\` **`
                                                )
                                                .setColor('#00dfff'),
                                        ],
                                        components: [],
                                    });
                                } catch {
                                    await btnInteraction.editReply({
                                        embeds: [
                                            new EmbedBuilder()
                                                .setDescription('**⚠️ An error occurred while delivering the reward. Please try again.**')
                                                .setColor('#9013fe'),
                                        ],
                                        components: [],
                                    });
                                }
                            }
                        }, 1000);
                    } else {
                        await btnInteraction.update({
                            embeds: [
                                new EmbedBuilder()
                                    .setDescription('**<:emoji_301:1330622079820632075> - Wrong choice! The theft failed!**')
                                    .setColor('#00dfff'),
                            ],
                            components: [],
                        });
                    }

                    client.activeThefts.delete(interaction.user.id);
                });

                buttonCollector.on('end', (collected) => {
                    if (collected.size === 0) {
                        interaction.editReply({
                            embeds: [
                                new EmbedBuilder()
                                    .setDescription('**<:wrn:1272223053216219268> - Time is up! The theft has failed.**')
                                    .setColor('#00dfff'),
                            ],
                            components: [],
                        });

                        client.activeThefts.delete(interaction.user.id);
                    }
                });
            }, 10000);
        }
    },
};

function generateRandomSymbols(length) {
    const symbols = '!#$&~@%^*?';
    const used = new Set();
    let result = '';
    while (result.length < length) {
        const char = symbols[Math.floor(Math.random() * symbols.length)];
        if (!used.has(char)) {
            used.add(char);
            result += char;
        }
    }
    return result;
}

function shuffleArray(array) {
    return array.sort(() => Math.random() - 0.5);
}