const Discord = require('discord.js');
const guildBase = require("../../Models/guildBase");
const { addPolicePoint } = require('../../functions');
const userBase = require("../../Models/userBase");
const { code0_role } = require("../../config.json")
module.exports = {
    name: `interactionCreate`,
    run: async (interaction, client) => {
        if (!interaction.isStringSelectMenu() && !interaction.isModalSubmit() && !interaction.isButton()) return;

        if (interaction.customId.startsWith("panic_menu")) {
            let data = await guildBase.findOne({ guild: interaction.guild.id })
            if (!data) {
                data = new guildBase({ guild: interaction.guild.id })
                await data.save();
            }

            if (!data.police_admin) return interaction.reply({
                content: `:x: | تعذر استخدام الامر بسبب عدم تعيين رتبة العساكر`,
                ephemeral: true
            })

            if (!interaction.guild.roles.cache.get(data.police_admin)) return interaction.reply({
                content: `:x: | تعذر استخدام الامر بسبب عدم إيجاد رتبة العساكر داخل السيرفر`,
                ephemeral: true
            })

            if (!interaction.member.roles.cache.has(data.police_admin)) return interaction.reply({
                content: `:x: | هذا الزر للعساكر فقط`,
                ephemeral: true
            })

            let check = data.policejoins.find(c => c.user === interaction.user.id)
            if (!check) return interaction.reply({
                content: `:x: | يجب تسجيل دخولك في المباشرين حتى تتمكن من استخدام الزر`,
                ephemeral: true
            })

            let value = interaction.values[0]

            if (value === "code_0") {
                if (!interaction.member.roles.cache.has(code0_role)) return interaction.reply({
                    content: `:x: | لا يمكنك استخدام هذا الاختيار`,
                    ephemeral: true
                })

                let embed = new Discord.EmbedBuilder()
                    .setColor("#030292")
                    .setDescription(`**<:LSPD:1256478539579002920> - Code 0 .

\`\` Police System . \`\` **`)
                    .setImage("https://media.discordapp.net/attachments/1336437701527732324/1337776428376395836/KBdbtedwIx.jpg?ex=67a8ace3&is=67a75b63&hm=39c0a20bfec6a2035e18f137da6ba367f6f9599c2d585f750c523a29dcfa680b&")

                let msg = await interaction.guild.channels.cache.get(data.panic_cahnnel)?.send({
                    embeds: [embed],
                    content: `<@&${data.police_admin}>`
                })

                let isRed = false
                let interval = setInterval(function () {
                    msg.edit({
                        embeds: [Discord.EmbedBuilder.from(msg.embeds[0]).setColor(isRed ? "#030292" : "#FF0000")]
                    })
                    isRed = !isRed
                }, 1000)

                setTimeout(() => { 
                    clearInterval(interval)
                    msg.edit({
                        embeds: [Discord.EmbedBuilder.from(msg.embeds[0]).setColor(isRed ? "#030292" : "#FF0000")]
                    })
                }, 60000 );

                return interaction.reply({
                    content: `:white_check_mark: | تم إرسال بلاغك للعساكر`,
                    ephemeral: true
                })
            }

            let modal = new Discord.ModalBuilder()
                .setCustomId(`panicModal_${value}`)
                .setTitle('Create a new panic');

            if (value === "shot" || value === "robbery_store") {
                const location = new Discord.TextInputBuilder()
                    .setCustomId('location')
                    .setLabel("What's your location")
                    .setStyle("Short");

                const row1 = new Discord.ActionRowBuilder().addComponents(location);

                modal.addComponents(row1);
            } else if (value === "vehicle" || value === "vehicleTheft") {
                const location = new Discord.TextInputBuilder()
                    .setCustomId('location')
                    .setLabel("What's your location")
                    .setStyle("Short");

                const vehicle = new Discord.TextInputBuilder()
                    .setCustomId('vehicle')
                    .setLabel("What's your vehicle")
                    .setStyle("Short");

                const color = new Discord.TextInputBuilder()
                    .setCustomId('color')
                    .setLabel("What's your color")
                    .setStyle("Short");

                const row1 = new Discord.ActionRowBuilder().addComponents(location);
                const row2 = new Discord.ActionRowBuilder().addComponents(vehicle);
                const row3 = new Discord.ActionRowBuilder().addComponents(color);

                modal.addComponents(row1, row2, row3);
            } else if (value === "shot" || value === "robberyStore" || value === "ppanic") {
                const location = new Discord.TextInputBuilder()
                    .setCustomId('location')
                    .setLabel("What's your location")
                    .setStyle("Short");

                const row1 = new Discord.ActionRowBuilder().addComponents(location);

                modal.addComponents(row1);
            }

            interaction.message.edit({ components: interaction.message.components })
            await interaction.showModal(modal);
        }

        else if (interaction.customId.startsWith("panicModal")) {
            let db = await guildBase.findOne({ guild: interaction.guild.id })
            if (!db.panic_cahnnel || !interaction.guild.channels.cache.get(db.panic_cahnnel)) return interaction.reply({
                content: `:x: | لا أستطع إيجاد روم البانيك`,
                ephemeral: true
            });

            let embed = new Discord.EmbedBuilder()
                .setColor("#030292")
                .setImage("https://media.discordapp.net/attachments/1336437701527732324/1337776428376395836/KBdbtedwIx.jpg?ex=67a8ace3&is=67a75b63&hm=39c0a20bfec6a2035e18f137da6ba367f6f9599c2d585f750c523a29dcfa680b&")

            let value = interaction.customId.split("_")[1]
            let row = [];
            if (value === "shot") {
                let location = interaction.fields.getTextInputValue('location');

                embed.setTitle(`<:LSPD:1256478539579002920> - 10-13 Shots Fired .`)
                    .setDescription(`**A male Firing a Weapon at ( ${location} )

\`\` Police System . \`\` **`);

                row = new Discord.ActionRowBuilder().addComponents(
                    new Discord.ButtonBuilder()
                        .setCustomId("panicClaim_2")
                        .setLabel("Claim")
                        .setStyle("Success")
                )
            } else if (value === "vehicle") {
                let location = interaction.fields.getTextInputValue('location');
                let vehicle = interaction.fields.getTextInputValue('vehicle');
                let color = interaction.fields.getTextInputValue('color');

                embed.setTitle(`<:LSPD:1256478539579002920> - 1-10 Vehicle chase operation .`)
                    .setDescription(`**Theft at ( ${location} ) 

<:1OL_1ruless:1252516289457553456> -  Vehicle | ${vehicle}
<:1OL_1ruless:1252516289457553456> - Color | ${color}

\`\` Police System . \`\` **`);
            } else if (value === "vehicleTheft") {
                let location = interaction.fields.getTextInputValue('location');
                let vehicle = interaction.fields.getTextInputValue('vehicle');
                let color = interaction.fields.getTextInputValue('color');

                embed.setTitle(`<:LSPD:1256478539579002920> - 5-10 Vehicle theft .`)
                    .setDescription(`**Theft at ( ${location} ) 

<:1OL_1ruless:1252516289457553456> -  Vehicle | ${vehicle}
<:1OL_1ruless:1252516289457553456> - Color | ${color}

\`\` Police System . \`\` **`);

                row = new Discord.ActionRowBuilder().addComponents(
                    new Discord.ButtonBuilder()
                        .setCustomId("panicClaim_3")
                        .setLabel("Claim")
                        .setStyle("Success")
                )
            } else if (value === "robberyStore") {
                let location = interaction.fields.getTextInputValue('location');

                embed.setTitle(`<:LSPD:1256478539579002920> - 7-10 Robbery Store .`)
                    .setDescription(`**The Robbery at ( ${location} ) 

\`\` Police System . \`\` **`);

                row = new Discord.ActionRowBuilder().addComponents(
                    new Discord.ButtonBuilder()
                        .setCustomId("panicClaim_3")
                        .setLabel("Claim")
                        .setStyle("Success")
                )
            } else if (value === "ppanic") {
                let location = interaction.fields.getTextInputValue('location');

                let check = db.policejoins.find(c => c.user === interaction.user.id)
                let dd = await userBase.findOne({ guild: interaction.guild.id, user: interaction.user.id })
                dd = dd[check.character]

                embed.setTitle(`<:LSPD:1256478539579002920> - Officer Down Kidnapping Police Officer . `)
                    .setDescription(`**From | ( ${dd.id.first} ) 
Location | ${location}

\`\` Police System . \`\` **`);

                row = new Discord.ActionRowBuilder().addComponents(
                    new Discord.ButtonBuilder()
                        .setCustomId("panicClaim_5")
                        .setLabel("Claim")
                        .setStyle("Success")
                )
            }

            await interaction.guild.channels.cache.get(db.panic_cahnnel)?.send({
                embeds: [embed],
                content: `<@&${db.police_admin}>`,
                components: row.length == 0 ? row : [row]
            })

            interaction.reply({
                content: `:white_check_mark: | تم إرسال بلاغك للعساكر`,
                ephemeral: true
            })
        } else if (interaction.customId.startsWith("panicClaim")) {
            let data = await guildBase.findOne({ guild: interaction.guild.id })

            if (!data.police_admin) return interaction.reply({
                content: `:x: | تعذر استخدام الامر بسبب عدم تعيين رتبة العساكر`,
                ephemeral: true
            })

            if (!interaction.guild.roles.cache.get(data.police_admin)) return interaction.reply({
                content: `:x: | تعذر استخدام الامر بسبب عدم إيجاد رتبة العساكر داخل السيرفر`,
                ephemeral: true
            })

            if (!interaction.member.roles.cache.has(data.police_admin)) return interaction.reply({
                content: `:x: | هذا الزر للعساكر فقط`,
                ephemeral: true
            })

            let check = data.policejoins.find(c => c.user === interaction.user.id)
            if (!check) return interaction.reply({
                content: `:x: | يجب تسجيل دخولك في المباشرين حتى تتمكن من استخدام الزر`,
                ephemeral: true
            })

            let row = Discord.ActionRowBuilder.from(interaction.message.components[0]).setComponents(
                Discord.ButtonBuilder.from(interaction.message.components[0].components[0]).setDisabled(true)
            )

            interaction.message.edit({ components: [row] })

            let amount = Number(interaction.customId.split("_")[1])

            await addPolicePoint(interaction.guild.id, interaction.user.id, check.character, "claim_report", amount)

            interaction.reply({
                content: `:white_check_mark: - تم إستلام البلاغ وحصلت على نقطتين إضافيتين`,
                ephemeral: true
            })
        }
    }
}