const { ActivityType } = require('discord.js');
const config = require('../../config.json'); // تأكد من وجود ملف "config.json" ويحتوي على "prefix"

module.exports = {
    name: 'ready',
    run: async (client) => {
        console.log(`✅ Logged in as ${client.user.tag}`);
        console.log(`🌍 The bot is working in ${client.guilds.cache.size} servers`);
        console.log(`👥 Total users: ${client.users.cache.reduce((acc, guild) => acc + guild.memberCount, 0)}`);
        console.log(`📡 Bot Ping: ${client.ws.ping} ms`);
        console.log(`🤖 Prefix: ${config.prefix}`);
        console.log(`👨‍💻 Bot Programmer: 88mv`);

        // ضبط حالة البوت عند التشغيل
        client.user.setPresence({
            activities: [{ 
                name: 'TLRP ON TOP',
                type: ActivityType.Streaming,
                url: 'https://twitch.tv/haider'
            }],
            status: 'online' // يمكن تغييره إلى "dnd" أو "idle"
        });
    }
};