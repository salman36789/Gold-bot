const Discord = require('discord.js')
    , guildBase = require('../../Models/guildBase')
    , userBase = require('../../Models/userBase')

module.exports = {
    name: `interactionCreate`,
    run: async (interaction, client) => {
        if (!interaction.isModalSubmit()) return;

        if (interaction.customId.startsWith("reportGmc")) {
            const Sony = interaction.fields.getTextInputValue('sony_id')
                , Report = interaction.fields.getTextInputValue('report')
                , Player = interaction.customId.split("_")[1]

            let embed = new Discord.EmbedBuilder()
                .setColor("#00dfff")
                .setImage("https://i.postimg.cc/jSsYsncH/Whats-App-Image-2025-01-14-at-7-41-43-PM.jpg")
                .setDescription(`**<:emoji_121:1252954003013242921> - GMC 

<:group2:1328358692676046879> - Player | <@${Player}>

<:emoji_121:1252954003013242921> - Report | ${Report}

<:tl:1262585314787201034> - Sony Id | ${Sony}

\`\` TOWN LAW System . \`\`**`);

            let row = new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId(`reportAccept_gmc_${interaction.user.id}`)
                    .setLabel("قبول البلاغ")
                    .setStyle("Success"),

                new Discord.ButtonBuilder()
                    .setCustomId(`reportReject_gmc_${interaction.user.id}`)
                    .setLabel("رفض البلاغ")
                    .setStyle("Danger")
            )

            let data = await guildBase.findOne({ guild: interaction.guild.id })
            let ch = interaction.guild.channels.cache.get(data.phone.gmc)
            if (!ch) return interaction.reply({
                content: `:x: | تعذر إرسال البلاغ بسبب عدم العثور على شات البلاغ`,
                ephemeral: true
            })

            ch.send({
                embeds: [embed],
                content: `${interaction.user}`,
                components: [row]
            })

            await interaction.reply({
                content: `:white_check_mark: | تم إرسال بلاغك للمراجعة`,
                ephemeral: true
            })
        }
    }
};