const { lineImage } = require("../../config.json")
module.exports = {
    name: `messageCreate`,
    run: async (message, client) => {
        if(message.content.startsWith("خط") || message.content.startsWith("-خط")) {
         if(!message.member?.roles.cache.has("1328570412866736166")) return;
            
            message.delete();

            await message.channel.send({ files: [lineImage] })
        }
    }
};