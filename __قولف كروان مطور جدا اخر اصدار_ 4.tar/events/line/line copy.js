const { lineImage, allowedChannels } = require("../../config.json");

module.exports = {
    name: "messageCreate",
    run: async (message, client) => {
        try {
            if (!message.guild) return; // التأكد من أن الرسالة في سيرفر وليس في الخاص

            // التحقق من أن الرسالة في إحدى الغرف المسموح بها
            if (!allowedChannels.includes(message.channel.id)) return;

            // التحقق من صلاحيات البوت
            if (!message.guild.members.me.permissions.has(["SEND_MESSAGES", "ATTACH_FILES", "MANAGE_MESSAGES","ADMINISTRATOR"])) {
                return console.log("البوت يفتقر إلى الصلاحيات اللازمة.");
            }

            // حذف الرسالة المرسلة
            await message.delete();

            // إرسال الصورة تلقائيًا
            if (lineImage) {
                await message.channel.send({ files: [lineImage] });
            } else {
                console.log("لم يتم العثور على رابط الصورة في config.json.");
            }

        } catch (error) {
            console.error("حدث خطأ أثناء إرسال الصورة تلقائيًا:", error);
        }
    }
};