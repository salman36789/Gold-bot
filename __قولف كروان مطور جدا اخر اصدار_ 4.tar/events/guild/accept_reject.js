const Discord = require('discord.js')
    , guildBase = require('../../Models/guildBase')
    , userBase = require('../../Models/userBase')
    , { addPoint } = require("../../functions");

module.exports = {
    name: `interactionCreate`,
    run: async (interaction, client) => {
        if (!interaction.isButton()) return;

        if (interaction.customId.startsWith("reject")) {
            let data = await guildBase.findOne({ guild: interaction.guild.id })
            if (!data) {
                data = new guildBase({ guild: interaction.guild.id })
                await data.save();
            }

            if (!data.idd || !data.idd.admin) return interaction.reply({
                content: `:x: | تعذر رفض الهوية بسبب عدم تعيين مسؤولين الهويات`,
                ephemeral: true
            })

            if(!interaction.guild.roles.cache.get(data.idd.admin)) return interaction.reply({
                content: `:x: | لا أستطيع ايجاد رتبة المسؤولين داخل السيرفر`,
                ephemeral: true
            })

            if(!interaction.member.roles.cache.has(data.idd.admin)) return interaction.reply({
                content: `:x: | ليس لديك صلاحيات لاستخدام هذا الزر لانك غير مسؤول عن الهويات`,
                ephemeral: true
            })

            const userId = interaction.customId.split("_")[1]
            const character = interaction.customId.split("_")[2]

            let db = await userBase.findOne({ guild: interaction.guild.id, user: userId })
            db = db[character]

            const row = Discord.ActionRowBuilder.from(interaction.message.components[0]);
            row.components.forEach(button => button.setDisabled(true));

            let embed = new Discord.EmbedBuilder()
                .setColor("#00dfff")
                .setImage("https://i.postimg.cc/jSsYsncH/Whats-App-Image-2025-01-14-at-7-41-43-PM.jpg")
                .setDescription(`**<:emoji_121:1252954003013242921> - تم رفض هويتك

يرجى قراءة القوانين بشكل جيد واعادة التقديم مره اخرى**`);

            let row2 = new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder()
                    .setStyle(Discord.ButtonStyle.Link)
                    .setURL("https://discord.com/channels/1131135581548724236/1328571153773494272")
                    .setEmoji("<:emoji_121:1252954003013242921>")
                    .setLabel("Character Rules")
            )

            await userBase.updateOne({ guild: interaction.guild.id, user: userId },
                {
                    $set: {
                        [`${character}.id`]: {}
                    }
                }
            );

            interaction.message.edit({
                components: [row]
            })

            let member = interaction.guild.members.cache.get(userId)
            if (!member) return interaction.reply({
                content: `:x: | لا أستطيع ايجاد هذا العضو داخل السيرفر لذلك تعذر إرسال رسالة الرفض`
            })

            member.send({
                components: [row2],
                embeds: [embed]
            })

            await interaction.reply({
                content: `:white_check_mark: | تم رفض الهوية`,
                ephemeral: true
            })

            addPoint(interaction.guild.id, interaction.user.id, "id", 1)

            if(!data.idd.log) return;

            let ch = interaction.guild.channels.cache.get(data.idd.log)
            if(!ch) return;

            ch.send({
                embeds: [new Discord.EmbedBuilder().setColor("#00dfff").setDescription(`** <:tl:1262585330813636618> - تم رفض هوية | ${member}

<:tl:1262585314787201034> - رقم الشخصية | ${character === "c1" ? "1" : "2"}

<:Active_MN:1289287993181474817> - الاداري المسؤول | ${interaction.user}

TOWN LAW System . **`)]
            })
        } else if (interaction.customId.startsWith("accept")) {
            let data = await guildBase.findOne({ guild: interaction.guild.id })
            if (!data) {
                data = new guildBase({ guild: interaction.guild.id })
                await data.save();
            }

            if (!data.idd || !data.idd.admin) return interaction.reply({
                content: `:x: | تعذر قبول الهوية بسبب عدم تعيين مسؤولين الهويات`,
                ephemeral: true
            })

            if(!interaction.guild.roles.cache.get(data.idd.admin)) return interaction.reply({
                content: `:x: | لا أستطيع ايجاد رتبة المسؤولين داخل السيرفر`,
                ephemeral: true
            })

            if(!interaction.member.roles.cache.has(data.idd.admin)) return interaction.reply({
                content: `:x: | ليس لديك صلاحيات لاستخدام هذا الزر لانك غير مسؤول عن الهويات`,
                ephemeral: true
            })

            if (!data.idd.role) return interaction.reply({
                content: `:x: | تعذر قبول الهوية بسبب عدم تعيين رتبة الهويات`,
                ephemeral: true
            })

            if(!interaction.guild.roles.cache.get(data.idd.role)) return interaction.reply({
                content: `:x: | لا أستطيع ايجاد رتبة الهويات داخل السيرفر`,
                ephemeral: true
            })

            const userId = interaction.customId.split("_")[1]
            const character = interaction.customId.split("_")[2]

            let db = await userBase.findOne({ guild: interaction.guild.id, user: userId })
            db = db[character]

            const row = Discord.ActionRowBuilder.from(interaction.message.components[0]);
            row.components.forEach(button => button.setDisabled(true));

            let iban = `${Math.floor(Math.random()* 1E16)}`
            let embed = new Discord.EmbedBuilder()
                .setColor("#00dfff")
                .setImage("https://i.postimg.cc/jSsYsncH/Whats-App-Image-2025-01-14-at-7-41-43-PM.jpg")
                .setDescription(`**<:1OL_1mute3:1288375881907048490> تم قبول هويتك 

<:tl:1262585314787201034> - Character  Number | ${character === "c1" ? "1" : "2"}

<:TLRP:1289346762472947814> - First Name | ${db.id.first}

<:TLRP:1289346762472947814> - Last Name | ${db.id.last}

<:TLRP:1289346762472947814> - Birthday | ${db.id.date}

<:TLRP:1289346762472947814> - GENDER | ${db.id.gender}

<:TLRP:1289346762472947814> - Birth Place | ${db.id.place}

<:1OL_1rules:1252221662129160224> - Iban | ${iban}**`);

            let row2 = new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder()
                    .setStyle(Discord.ButtonStyle.Link)
                    .setURL("https://discord.com/channels/1131135581548724236/1328571127689383977")
                    .setEmoji("<:emoji_121:1252954003013242921>")
                    .setLabel("Play"),

                new Discord.ButtonBuilder()
                    .setStyle(Discord.ButtonStyle.Link)
                    .setURL("https://discord.com/channels/1131135581548724236/1254546298497929337")
                    .setEmoji("<:emoji_121:1252954003013242921>")
                    .setLabel("Rules")
            )

            db.id.accepted = true
            db.id.iban = iban
            await userBase.updateOne({ guild: interaction.guild.id, user: userId },
                {
                    $set: {
                        [`${character}.id`]: db.id
                    }
                }
            );

            interaction.message.edit({
                components: [row]
            })

            let member = interaction.guild.members.cache.get(userId)
            if (!member) return interaction.reply({
                content: `:x: | لا أستطيع ايجاد هذا العضو داخل السيرفر لذلك تعذر إرسال رسالة القبول`
            })

            member.send({
                components: [row2],
                embeds: [embed]
            })

            member.roles.add(data.idd.role)

            await interaction.reply({
                content: `:white_check_mark: | تم قبول الهوية`,
                ephemeral: true
            })

            addPoint(interaction.guild.id, interaction.user.id, "id", 1)

            if(!data.idd.log) return;

            let ch = interaction.guild.channels.cache.get(data.idd.log)
            if(!ch) return;

            ch.send({
                embeds: [new Discord.EmbedBuilder().setColor("#00dfff").setDescription(`** <:tl:1262585330813636618> - تم قبول هوية | ${member}

<:tl:1262585314787201034> - رقم الشخصية | ${character === "c1" ? "1" : "2"}

<:Active_MN:1289287993181474817> - الاداري المسؤول | ${interaction.user}

TOWN LAW System .**`)]
            })
        }
    }
};