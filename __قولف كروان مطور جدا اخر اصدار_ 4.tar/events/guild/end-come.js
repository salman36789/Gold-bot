const Discord = require('discord.js')
    , guildBase = require('../../Models/guildBase')
    , userBase = require('../../Models/userBase')
    , { addPoint } = require("../../functions");

module.exports = {
    name: `interactionCreate`,
    run: async (interaction, client) => {
        if (!interaction.isButton()) return;

        if (interaction.customId.startsWith("endCome")) {
            let user = interaction.customId.split("_")[1]
            if (interaction.user.id != user) return interaction.reply({
                content: `:x: | لا يمكنك استخدام هذا الزر`,
                ephemeral: true
            })

            let memberId = interaction.customId.split("_")[2]
            let member = interaction.guild.members.cache.get(memberId)
            if (!member) return interaction.reply({
                content: `:x: | لا استطيع ايجاد العضو داخل هذا السيرفر`,
                ephemeral: true
            })

            member.send({
                embeds: [new Discord.EmbedBuilder().setColor("#00dfff")
                    .setImage("https://i.postimg.cc/jSsYsncH/Whats-App-Image-2025-01-14-at-7-41-43-PM.jpg")
                    .setDescription(`**<:emoji_121:1252954003013242921> - TOWN LAW System .

<:2_Warne:1134085602233569350> - عزيزي اللاعب | ${member}
تم الانتهاء من الاستدعاء بشكل ناجح
من قبل الإداري | ${interaction.user}

متمنين لك التوفيق - <:tl:1262585330813636618>**`)]
            }).then(async () => {
                let herer = new Discord.EmbedBuilder()
                .setColor("#00dfff")
                .setDescription(`:white_check_mark: | تم إنهاء الاستدعاء وإضافة 4 نقاط ادارية`)

                await interaction.message.edit({
                    components: [],
                    embeds: [herer]
                })
            }).catch(async () => {
                let herer = new Discord.EmbedBuilder()
                .setColor("#00dfff")
                .setDescription(`:x: | تم إضافة لك 4 نقاط ادارية لكن لم اتمكن من إرسال رسالة الانهاء للعضو`)

                await interaction.message.edit({
                    components: [],
                    embeds: [herer]
                })
            })

            addPoint(interaction.guild.id, interaction.user.id, "take_report", 4)

            let data = await guildBase.findOne({ guild: interaction.guild.id })

            let ch = interaction.guild.channels.cache.get(data.comes.log)
            if (!ch) return;

            let type = interaction.customId.split("_")[3]

            ch.send({
                embeds: [new Discord.EmbedBuilder().setColor("#00dfff").setDescription(`** <:employeemanalt:1328359209070493837> - انهاء الاستدعاء العضو |

<:tl:1262585314787201034> - من قبل الاداري | ${interaction.user}

<:1OL_1rules:1252221662129160224> - نوع الاستدعاء | ${type}**`)]
            })
        }
    }
};