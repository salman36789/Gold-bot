const Discord = require('discord.js')
    , guildBase = require('../../Models/guildBase')
    , { addPoint, checkCount } = require("../../functions");

let interval;
module.exports = {
    name: `interactionCreate`,
    run: async (interaction, client) => {
        if (!interaction.isModalSubmit()) return;

        if (interaction.customId.startsWith("createGame")) {
            let data = await guildBase.findOne({ guild: interaction.guild.id })
            if (!data) {
                data = new guildBase({ guild: interaction.guild.id })
                await data.save();
            }

            let ch = interaction.guild.channels.cache.get(data.game_channels.start_game)
            if (!ch) return interaction.reply({
                content: `:x: | تعذر فتح القيم بسبب عدم إيجاد روم فتح الاقيام داخل هذا السيرفر`,
                ephemeral: true
            })

            const hostId = interaction.fields.getTextInputValue('host_id')
               // , hostHand = interaction.fields.getTextInputValue('host_hand')
                , Time = interaction.fields.getTextInputValue('time');
             //   , Warns = interaction.fields.getTextInputValue('warns');

            let row = new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder()
                    .setStyle(Discord.ButtonStyle.Link)
                    .setURL("https://discord.com/channels/1131135581548724236/1254546298497929337")
                    .setEmoji("<:emoji_121:1252954003013242921>")
                    .setLabel("Rules"),

                new Discord.ButtonBuilder()
                    .setStyle(Discord.ButtonStyle.Link)
                    .setURL("https://discord.com/channels/1131135581548724236/1328571127689383977")
                    .setEmoji("<:emoji_121:1252954003013242921>")
                    .setLabel("Join Server")
            )

            let embedd = new Discord.EmbedBuilder()
                .setColor("#00dfff")
                .setImage("https://i.postimg.cc/jSsYsncH/Whats-App-Image-2025-01-14-at-7-41-43-PM.jpg")
                .setDescription(`**** <:1OL_1online:1252516288429953038> — Open Game Online  


If you enter the server, you must click on the emoji <:tl:1262585330813636618> 

<:emoji_285:1329556329177681922> — ID Host : ${hostId}

<:1OL_1clock3:1288375951654125649> — Game Time : ${Time}

<a:OL_BLeft1:1288390502986813511> — يجب عليك مراجعة التي متواجده ب الاسفل  


1 . تكون راسل طلب صداقة للهوست
2 . تكون حاط متصل 
3 . تاكد انك داخل قراند و داخل اونلاين 
4 . طريقة تجوين ( من بروفايل )

<:1OL_1warrn:1252516293379231764> — [ يجب قراءة قوانين السيرفر لتجنب المحاسبة ] 
<:1OL_1rulesx3:1288375905114128384> — [ في حال واجهتك مشكلة داخل السيرفر او خارج السيرفر [القيم] يمنع ذكره ب الشاتات العامة  يوجد عندك تذكرة الدعم الفني <#1328571116461101096> ]

<:emoji_121:1252954003013242921> | Town Law Management ****`)

            ch.send({
                embeds: [embedd],
                content: `|| @everyone ||`,
                components: [row]
            }).then(async msg => {
                await msg.react("<:tl:1262585330813636618>")
            })

            data.game = true
            await data.save();

            require("./games.js").startInterval(interaction.guild);

            let eem = new Discord.EmbedBuilder()
                .setColor("#00dfff")
                .setDescription(`**<:tl:1262585330813636618> - تم فتح القيم بنجاح و إضافة 5 نقاط إدارية لك**`)

            interaction.reply({
                embeds: [eem],
                ephemeral: true
            })

            addPoint(interaction.guild.id, interaction.user.id, "start_game", 5)
        } else if (interaction.customId.startsWith("renewGame")) {
            let data = await guildBase.findOne({ guild: interaction.guild.id })
            if (!data) {
                data = new guildBase({ guild: interaction.guild.id })
                await data.save();
            }

            let ch = interaction.guild.channels.cache.get(data.game_channels.ads)
            if (!ch) return interaction.reply({
                content: `:x: | تعذر تجديد القيم بسبب عدم إيجاد روم تنبيهات الاقيام داخل هذا السيرفر`,
                ephemeral: true
            })

            const hostId = interaction.fields.getTextInputValue('host_id')

            let embedd = new Discord.EmbedBuilder()
                .setColor("#00dfff")
                .setImage("https://i.postimg.cc/jSsYsncH/Whats-App-Image-2025-01-14-at-7-41-43-PM.jpg")
                .setDescription(`**<:emoji_121:1252954003013242921> - اشعار تجديد 

<:1OL_1warrn:1252516293379231764> - يوجد تجديد رحلة 
الرجاء من الجميع وضع خيار ( Last Location ) والخروج من الرحلة ودخول على الرحلة الجديدة 
<:tl:1262585314787201034> - ايدي الهوست | ${hostId}

متمنين لكم التوفيق - <:tl:1262585330813636618>**`)

            ch.send({
                embeds: [embedd],
                content: `|| @everyone ||`
            })
            
            data.game = true
            await data.save();
            interaction.reply({
                content: `:white_check_mark: | تم تجديد القيم بنجاح`,
                ephemeral: true
            })
        } else if (interaction.customId.startsWith("aler.tGame")) {
            let data = await guildBase.findOne({ guild: interaction.guild.id })
            if (!data) {
                data = new guildBase({ guild: interaction.guild.id })
                await data.save();
            }

            let ch = interaction.guild.channels.cache.get(data.game_channels.ads)
            if (!ch) return interaction.reply({
                content: `:x: | تعذر وضع تنبيهات للقيم بسبب عدم إيجاد روم تنبيهات الاقيام داخل هذا السيرفر`,
                ephemeral: true
            })

            const ADS = interaction.fields.getTextInputValue('ads')

            let embedd = new Discord.EmbedBuilder()
                .setColor("#00dfff")
                .setImage("https://i.postimg.cc/jSsYsncH/Whats-App-Image-2025-01-14-at-7-41-43-PM.jpg")
                .setDescription(`**<:emoji_121:1252954003013242921> - اشعار تنبيه اداري 

<:1OL_1warrn:1252516293379231764> - التنبية | ${ADS}

متمنين لكم التوفيق - <:tl:1262585330813636618>**`)

            ch.send({
                embeds: [embedd],
                content: `|| @everyone ||`
            })

            interaction.reply({
                content: `:white_check_mark: | تم تجديد القيم بنجاح`,
                ephemeral: true
            })
        }
    },

    startInterval: (guild) => {
        interval = setInterval(() => {
            checkCount(guild);
        }, 2700000);
    },

    endInterval: () => {
        if (interval) {
            clearInterval(interval);
        }
    }
};