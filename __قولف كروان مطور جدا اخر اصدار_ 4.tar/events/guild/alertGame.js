const { AttachmentBuilder, EmbedBuilder } = require('discord.js');
const { createCanvas } = require('canvas');
const guildBase = require('../../Models/guildBase');

module.exports = {
    name: `interactionCreate`,
    run: async (interaction, client) => {
        if (!interaction.isModalSubmit()) return;
        if (interaction.customId.startsWith("alertGame")) {
            let data = await guildBase.findOne({ guild: interaction.guild.id });
            if (!data) {
                data = new guildBase({ guild: interaction.guild.id });
                await data.save();
            }

            let ch = interaction.guild.channels.cache.get(data.game_channels.ads);
            if (!ch) {
                return interaction.reply({
                    content: `** <:emoji_308:1330691798921773137> - تعذر وضع تنبيهات للقيم بسبب عدم إيجاد روم تنبيهات الاقيام داخل هذا السيرفر .**`,
                    ephemeral: true
                });
            }

            const ADS = interaction.fields.getTextInputValue('ads');
            const adminUsername = interaction.user.username;

            // إنشاء الصورة باستخدام Canvas
            const canvas = createCanvas (800, 250);
            const ctx = canvas.getContext('2d');
            ctx.fillStyle = '#1E90FF';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.font = '30px Arial';
            ctx.fillStyle = '#000000';
            ctx.fillText(`Server Announcements by TL Admin: ${adminUsername}`, 50, 50);
            ctx.font = '80px Arial';
            ctx.fillText('⚠️', 50, 130);
            ctx.font = '30px Arial';
            ctx.fillText('Announcements Messages .', 50, 180);
            ctx.fillText(`Alert: ${ADS}`, 50, 220);
            
            const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'alert.png' });

            // إنشاء الإيمبيد
            const embed = new EmbedBuilder()
                .setColor(0x1E90FF)
                .setTitle(`** Important Alert <:tlWarn:1348797073121738803> **`)
                .setDescription(`**<:wrn:1272223053216219268> New alert from the Management**\n\n** – ${ADS}**`)
                .addFields({ name: '**<:tl:1347101347610365962> — Responsible for the alert **', value: `** ${adminUsername} **` })
                .setImage('attachment://alert.png') // ربط الصورة بالإيمبيد
                .setFooter({ text: 'Please read the alert .', iconURL: interaction.user.displayAvatarURL() })
                .setTimestamp();

            // إرسال الإيمبيد مع الصورة
            ch.send({ embeds: [embed], files: [attachment], content: `|| @everyone ||` });

            interaction.reply({ content: `**<:emoji_301:1330622165019529329> - تم ارسال التنبيه.**`, ephemeral: true });
        }
    }
};